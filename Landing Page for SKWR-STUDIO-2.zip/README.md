
  # Landing Page for SKWR-STUDIO

  This is a code bundle for Landing Page for SKWR-STUDIO. The original project is available at https://www.figma.com/design/mInCkw8CkaICdBnHGKQDIS/Landing-Page-for-SKWR-STUDIO.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  