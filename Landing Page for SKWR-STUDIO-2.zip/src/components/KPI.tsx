interface KPIProps {
  value: string;
  label: string;
  variant?: "default" | "accent";
}

export function KPI({ value, label, variant = "default" }: KPIProps) {
  return (
    <div className="flex flex-col gap-3">
      <div
        className={`font-['Space_Grotesk'] ${
          variant === "accent" ? "text-[#E01919]" : "text-[#111111]"
        }`}
      >
        {value}
      </div>
      <div className="text-[#666666]">{label}</div>
    </div>
  );
}
