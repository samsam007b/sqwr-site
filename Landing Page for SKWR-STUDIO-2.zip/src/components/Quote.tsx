interface QuoteProps {
  text: string;
  author: string;
  role: string;
}

export function Quote({ text, author, role }: QuoteProps) {
  return (
    <div className="relative p-12 glass-surface rounded-[8px]">
      {/* Quote mark */}
      <div className="absolute top-8 left-8 w-10 h-10 flex items-center justify-center">
        <div className="w-7 h-7 border-l-[1.5px] border-t-[1.5px] border-[#E01919] opacity-50"></div>
      </div>

      <div className="pl-12">
        <p className="text-[#111111] mb-8 italic opacity-85 leading-relaxed">{text}</p>
        <div className="flex items-center gap-4">
          <div className="w-[2px] h-10 bg-[#E01919] rounded-full"></div>
          <div>
            <div className="text-[#111111] font-['Space_Grotesk'] mb-1">{author}</div>
            <div className="text-[#666666]">{role}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
