import { Badge } from "./ui/badge";

interface ProjectCardProps {
  image: string;
  title: string;
  client: string;
  poles: string[];
  result: string;
  size?: "small" | "medium" | "large";
  onClick?: () => void;
}

export function ProjectCard({
  image,
  title,
  client,
  poles,
  result,
  size = "medium",
  onClick,
}: ProjectCardProps) {
  const sizeClasses = {
    small: "h-[480px]",
    medium: "h-[560px]",
    large: "h-[680px]",
  };

  return (
    <button
      onClick={onClick}
      className={`group relative ${sizeClasses[size]} w-full overflow-hidden glass-surface rounded-[8px] glass-hover text-left`}
    >
      {/* Image */}
      <div className="absolute inset-0 overflow-hidden rounded-[8px]">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover transition-all duration-[400ms] group-hover:scale-[1.02]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#FAFAF8] via-[#FAFAF8]/30 to-transparent opacity-90"></div>
      </div>

      {/* Content */}
      <div className="absolute inset-0 p-12 flex flex-col justify-end">
        {/* Tags */}
        <div className="flex flex-wrap gap-2 mb-6">
          {poles.map((pole) => (
            <Badge
              key={pole}
              variant="outline"
              className="border-[#E6E6E6] text-[#777777] bg-white/50 backdrop-blur-sm px-3 py-1 rounded-[4px] mono tracking-wide"
            >
              {pole.toUpperCase()}
            </Badge>
          ))}
        </div>

        {/* Title & Client */}
        <h3 className="font-['Space_Grotesk'] mb-3 text-[#111111] group-hover:text-[#E01919] transition-colors duration-200">
          {title}
        </h3>
        <p className="text-[#666666] mb-6">{client}</p>

        {/* Result */}
        <div className="flex items-center gap-2">
          <div className="w-[2px] h-[2px] bg-[#E01919] rounded-full"></div>
          <span className="text-[#111111]">{result}</span>
        </div>
      </div>

      {/* Hover indicator */}
      <div className="absolute top-8 right-8 w-10 h-10 border border-[#E6E6E6] rounded-[4px] flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-200 bg-white/60 backdrop-blur-sm">
        <svg
          width="14"
          height="14"
          viewBox="0 0 12 12"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M1 11L11 1M11 1H1M11 1V11"
            stroke="#111111"
            strokeWidth="1"
            strokeOpacity="0.5"
          />
        </svg>
      </div>
    </button>
  );
}
