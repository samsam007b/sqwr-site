interface PoleCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

export function PoleCard({ icon, title, description }: PoleCardProps) {
  return (
    <div className="group p-12 glass-surface rounded-[8px] glass-hover transition-all duration-200">
      {/* Icon */}
      <div className="w-20 h-20 mb-8 bg-white/50 rounded-[4px] flex items-center justify-center group-hover:bg-[#E01919]/5 transition-all duration-200">
        <div className="text-[#E01919] opacity-75">{icon}</div>
      </div>

      {/* Content */}
      <h3 className="text-[#111111] font-['Space_Grotesk'] mb-4">{title}</h3>
      <p className="text-[#666666] leading-relaxed">{description}</p>

      {/* Hover indicator */}
      <div className="mt-8 flex items-center gap-2 text-[#777777] group-hover:text-[#E01919] transition-colors duration-200">
        <span className="mono">DÉCOUVRIR</span>
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
          <path
            d="M3 8H13M13 8L8 3M13 8L8 13"
            stroke="currentColor"
            strokeWidth="1"
            strokeOpacity="0.7"
          />
        </svg>
      </div>
    </div>
  );
}
