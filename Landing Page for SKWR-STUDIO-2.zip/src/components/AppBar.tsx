import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import logoImage from "figma:asset/59c6382a831a111d077fbef2ea6614903dd75256.png";

interface AppBarProps {
  onNavigate?: (section: string) => void;
}

export function AppBar({ onNavigate }: AppBarProps) {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleNavClick = (section: string) => {
    if (onNavigate) {
      onNavigate(section);
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-240 ${
        scrolled ? "glass-surface border-b border-[#E6E6E6]" : "bg-transparent"
      }`}
    >
      <div className="max-w-[1440px] mx-auto px-12">
        <div className="flex items-center justify-between h-24">
          {/* Logo */}
          <button
            onClick={() => handleNavClick("home")}
            className="flex items-center gap-4 group transition-all duration-200 hover:opacity-75"
          >
            <img 
              src={logoImage} 
              alt="Skwer Studio" 
              className="h-16 w-auto"
              style={{ imageRendering: 'pixelated' }}
            />
            <span className="font-['Space_Grotesk'] tracking-tight text-[#111111]">STUDIO</span>
          </button>

          {/* Navigation */}
          <nav className="hidden md:flex items-center gap-12">
            {["Cases", "Services", "Studio", "Contact"].map((item) => (
              <button
                key={item}
                onClick={() => handleNavClick(item.toLowerCase())}
                className="relative text-[#666666] hover:text-[#111111] transition-all duration-200 group"
              >
                <span>{item}</span>
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#E01919] group-hover:w-full transition-all duration-240"></span>
              </button>
            ))}
          </nav>

          {/* CTA */}
          <Button
            onClick={() => handleNavClick("contact")}
            className="glass-surface hover:bg-[#111111] hover:text-white text-[#111111] px-8 h-12 rounded-[8px] border-0 transition-all duration-200 hover:translate-y-[-1px]"
          >
            Démarrer un projet
          </Button>
        </div>
      </div>
    </header>
  );
}
