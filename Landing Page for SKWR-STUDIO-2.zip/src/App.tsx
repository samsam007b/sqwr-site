import { useState, useRef, useEffect } from "react";
import { AppBar } from "./components/AppBar";
import { ProjectCard } from "./components/ProjectCard";
import { KPI } from "./components/KPI";
import { Quote } from "./components/Quote";
import { ProcessStep } from "./components/ProcessStep";
import { PoleCard } from "./components/PoleCard";
import { Footer } from "./components/Footer";
import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";
import { Textarea } from "./components/ui/textarea";
import { Label } from "./components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./components/ui/select";
import { Badge } from "./components/ui/badge";
import { projects, type Project } from "./data/projects";
import logoImage from "figma:asset/59c6382a831a111d077fbef2ea6614903dd75256.png";

type Page = "home" | "cases" | "case-detail" | "services" | "studio" | "contact";

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>("home");
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [filterPole, setFilterPole] = useState<string>("all");

  const homeRef = useRef<HTMLDivElement>(null);
  const casesRef = useRef<HTMLDivElement>(null);
  const servicesRef = useRef<HTMLDivElement>(null);
  const studioRef = useRef<HTMLDivElement>(null);
  const contactRef = useRef<HTMLDivElement>(null);

  const handleNavigate = (section: string) => {
    if (section === "home") {
      setCurrentPage("home");
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      setCurrentPage(section as Page);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const handleProjectClick = (project: Project) => {
    setSelectedProject(project);
    setCurrentPage("case-detail");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const featuredProjects = projects.slice(0, 6);
  const filteredProjects = filterPole === "all" 
    ? projects 
    : projects.filter(p => p.poles.includes(filterPole));

  return (
    <div className="min-h-screen bg-[#FAFAF8] text-[#111111] paper-texture">
      <AppBar onNavigate={handleNavigate} />

      {/* HOME PAGE */}
      {currentPage === "home" && (
        <div ref={homeRef}>
          {/* Hero Section */}
          <section className="min-h-screen flex items-center justify-center px-12 pt-24 relative">
            <div className="max-w-[1440px] mx-auto relative z-10 w-full">
              <div className="max-w-5xl">
                {/* Logo en hero */}
                <div className="mb-24 flex items-center gap-12">
                  <img 
                    src={logoImage} 
                    alt="Skwer Studio" 
                    className="h-64 w-auto"
                    style={{ imageRendering: 'pixelated' }}
                  />
                  <div className="h-48 w-[1px] bg-[#E6E6E6]"></div>
                  <span className="mono text-[#777777] tracking-[0.2em]">PREMIUM CREATIVE STUDIO</span>
                </div>
                <h1 className="text-[#111111] mb-12 font-['Space_Grotesk']">
                  Transformer vos <span className="text-[#E01919]">ambitions</span> en réalisations d'exception
                </h1>
                <p className="text-[#666666] max-w-2xl mb-16 leading-relaxed">
                  Agence familiale premium dédiée au design, au développement et à la communication. 
                  Nous créons des expériences qui marquent les esprits.
                </p>
                <div className="flex flex-wrap gap-6">
                  <Button
                    onClick={() => handleNavigate("contact")}
                    className="bg-[#E01919] hover:bg-[#111111] text-white px-10 h-14 rounded-[8px] transition-all duration-200 hover:translate-y-[-1px]"
                  >
                    Démarrer un projet
                  </Button>
                  <Button
                    onClick={() => handleNavigate("cases")}
                    variant="outline"
                    className="glass-surface hover:bg-white/90 text-[#111111] px-10 h-14 rounded-[8px] border-0 transition-all duration-200 hover:translate-y-[-1px]"
                  >
                    Voir nos réalisations
                  </Button>
                </div>
              </div>
            </div>
          </section>

          {/* 3 Pôles */}
          <section className="py-48 px-12 border-t border-[#E6E6E6]">
            <div className="max-w-[1440px] mx-auto">
              <div className="mb-24">
                <span className="text-[#E01919] mono tracking-[0.2em]">NOS PÔLES</span>
                <h2 className="text-[#111111] font-['Space_Grotesk'] mt-6">
                  Trois expertises,<br />une vision commune
                </h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <PoleCard
                  icon={
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                      <rect x="4" y="4" width="10" height="10" stroke="currentColor" strokeWidth="2" />
                      <rect x="18" y="4" width="10" height="10" stroke="currentColor" strokeWidth="2" />
                      <rect x="4" y="18" width="10" height="10" stroke="currentColor" strokeWidth="2" />
                      <rect x="18" y="18" width="10" height="10" stroke="currentColor" strokeWidth="2" />
                    </svg>
                  }
                  title="Graphisme"
                  description="Identités visuelles, design système, packaging et direction artistique. Nous créons des univers visuels cohérents et mémorables."
                />
                <PoleCard
                  icon={
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                      <path d="M8 8L24 8M24 8L24 24M24 8L8 24" stroke="currentColor" strokeWidth="2" />
                      <rect x="4" y="4" width="24" height="24" stroke="currentColor" strokeWidth="2" />
                    </svg>
                  }
                  title="Code"
                  description="Sites web, applications, plateformes SaaS et e-commerce. Développement sur-mesure avec les technologies les plus performantes."
                />
                <PoleCard
                  icon={
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                      <circle cx="16" cy="16" r="12" stroke="currentColor" strokeWidth="2" />
                      <circle cx="16" cy="16" r="6" stroke="currentColor" strokeWidth="2" />
                      <circle cx="16" cy="16" r="2" fill="currentColor" />
                    </svg>
                  }
                  title="Communication"
                  description="Stratégie de contenu, social media, campagnes et événementiel. Nous amplifions votre message auprès de vos audiences."
                />
              </div>
            </div>
          </section>

          {/* Cases Featured */}
          <section className="py-48 px-12">
            <div className="max-w-[1440px] mx-auto">
              <div className="flex justify-between items-end mb-24">
                <div>
                  <span className="text-[#E01919] mono tracking-[0.2em]">RÉALISATIONS</span>
                  <h2 className="text-[#111111] font-['Space_Grotesk'] mt-6">
                    Projets sélectionnés
                  </h2>
                </div>
                <Button
                  onClick={() => handleNavigate("cases")}
                  variant="ghost"
                  className="text-[#666666] hover:text-[#E01919] hidden md:flex items-center gap-2 transition-colors duration-200"
                >
                  <span className="mono tracking-[0.15em]">VOIR TOUS</span>
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <path d="M3 8H13M13 8L8 3M13 8L8 13" stroke="currentColor" strokeWidth="1" strokeOpacity="0.7" />
                  </svg>
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {featuredProjects.map((project, index) => (
                  <ProjectCard
                    key={project.id}
                    image={project.image}
                    title={project.title}
                    client={project.client}
                    poles={project.poles}
                    result={project.kpi1 + " " + project.kpi1Label}
                    size={index === 0 || index === 3 ? "large" : "medium"}
                    onClick={() => handleProjectClick(project)}
                  />
                ))}
              </div>
            </div>
          </section>

          {/* Process */}
          <section className="py-48 px-12 border-t border-[#E6E6E6]">
            <div className="max-w-[1440px] mx-auto">
              <div className="mb-24">
                <span className="text-[#E01919] mono tracking-[0.2em]">MÉTHODE</span>
                <h2 className="text-[#111111] font-['Space_Grotesk'] mt-6">
                  Notre approche
                </h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-16">
                <ProcessStep
                  number="01"
                  title="Écoute & Stratégie"
                  description="Nous commençons par comprendre vos enjeux, vos ambitions et votre ADN. Cette phase d'écoute nous permet de définir la stratégie créative la plus pertinente."
                />
                <ProcessStep
                  number="02"
                  title="Création & Développement"
                  description="Notre équipe conçoit et développe des solutions sur-mesure, en itérant avec vous à chaque étape pour garantir un résultat qui dépasse vos attentes."
                />
                <ProcessStep
                  number="03"
                  title="Lancement & Suivi"
                  description="Nous vous accompagnons dans le déploiement et restons à vos côtés pour mesurer les performances et optimiser en continu."
                />
              </div>
            </div>
          </section>

          {/* Preuves */}
          <section className="py-32 px-6 lg:px-12 bg-white/40 surface-texture">
            <div className="container mx-auto">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
                <div>
                  <span className="text-[#E01919] mono text-[13px] tracking-widest">RÉSULTATS</span>
                  <h2 className="text-[#111111] font-['Space_Grotesk'] mt-4 mb-12">
                    Des chiffres qui parlent
                  </h2>
                  <div className="grid grid-cols-2 gap-8">
                    <KPI value="50+" label="Projets livrés" variant="accent" />
                    <KPI value="98%" label="Satisfaction client" />
                    <KPI value="3.2×" label="ROI moyen" variant="accent" />
                    <KPI value="24h" label="Temps de réponse" />
                  </div>
                </div>
                <Quote
                  text="SKWR-STUDIO a su comprendre notre vision et la traduire en une identité visuelle forte qui nous différencie vraiment. L'équipe est réactive, créative et d'un professionnalisme exemplaire."
                  author="Marie Dubois"
                  role="CEO, SquareBrew Coffee"
                />
              </div>
            </div>
          </section>

          {/* Studio */}
          <section id="studio" ref={studioRef} className="py-32 px-6 lg:px-12 border-t border-[#00000014] light-leak-top">
            <div className="container mx-auto">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
                <div className="relative h-[500px] rounded-[12px] overflow-hidden glass-surface grain-overlay depth-shadow">
                  <img
                    src="https://images.unsplash.com/photo-1510074377623-8cf13fb86c08?w=800&q=80"
                    alt="Studio"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#FAFAF8] to-transparent opacity-50"></div>
                </div>
                <div>
                  <span className="text-[#E01919] mono text-[13px] tracking-widest">À PROPOS</span>
                  <h2 className="text-[#111111] font-['Space_Grotesk'] mt-4 mb-8">
                    Une agence familiale, des valeurs fortes
                  </h2>
                  <p className="text-[#666666] mb-6 leading-relaxed">
                    Fondé en 2019, SKWR-STUDIO est né de la volonté de créer une agence à taille humaine, 
                    capable de combiner expertise technique, sensibilité créative et relation client privilégiée.
                  </p>
                  <p className="text-[#666666] mb-8 leading-relaxed">
                    Aujourd'hui, notre équipe de 8 personnes travaille avec des clients partout en France 
                    et à l'international, sur des projets qui ont du sens et de l'impact.
                  </p>
                  <Button
                    onClick={() => handleNavigate("contact")}
                    className="bg-[#E01919] hover:bg-[#111111] text-white px-8 h-12 rounded-[4px] pixel-wave transition-all duration-220"
                  >
                    Rencontrons-nous
                  </Button>
                </div>
              </div>
            </div>
          </section>

          <Footer />
        </div>
      )}

      {/* CASES LISTING PAGE */}
      {currentPage === "cases" && (
        <div ref={casesRef} className="pt-32 pb-20 px-6 lg:px-12">
          <div className="container mx-auto">
            {/* Header */}
            <div className="mb-16">
              <button
                onClick={() => handleNavigate("home")}
                className="flex items-center gap-2 text-[#666666] hover:text-[#111111] mb-8 transition-colors"
              >
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                  <path d="M13 8H3M3 8L8 13M3 8L8 3" stroke="currentColor" strokeWidth="1" strokeOpacity="0.6" />
                </svg>
                <span className="text-[14px]">Retour</span>
              </button>
              <h1 className="text-[#111111] font-['Space_Grotesk'] mb-6">
                Nos réalisations
              </h1>
              <p className="text-[#666666] max-w-2xl text-[18px]">
                Une sélection de projets qui illustrent notre approche et notre savoir-faire.
              </p>
            </div>

            {/* Filters */}
            <div className="flex flex-wrap gap-3 mb-12">
              {["all", "Graphisme", "Code", "Communication"].map((pole) => (
                <button
                  key={pole}
                  onClick={() => setFilterPole(pole)}
                  className={`px-6 py-3 rounded-[4px] transition-all mono text-[12px] tracking-wide ${
                    filterPole === pole
                      ? "bg-[#E01919] text-white"
                      : "glass-surface text-[#666666] hover:bg-white/90"
                  }`}
                >
                  {pole === "all" ? "TOUS" : pole.toUpperCase()}
                </button>
              ))}
            </div>

            {/* Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProjects.map((project) => (
                <ProjectCard
                  key={project.id}
                  image={project.image}
                  title={project.title}
                  client={project.client}
                  poles={project.poles}
                  result={project.kpi1 + " " + project.kpi1Label}
                  onClick={() => handleProjectClick(project)}
                />
              ))}
            </div>
          </div>
          <Footer />
        </div>
      )}

      {/* CASE DETAIL PAGE */}
      {currentPage === "case-detail" && selectedProject && (
        <div className="pt-32 pb-20">
          {/* Hero */}
          <section className="relative h-[70vh] mb-20 rounded-[12px] overflow-hidden mx-6 lg:mx-12">
            <img
              src={selectedProject.image}
              alt={selectedProject.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#FAFAF8] via-[#FAFAF8]/50 to-transparent"></div>
            <div className="absolute inset-0 flex items-end">
              <div className="container mx-auto px-6 lg:px-12 pb-16">
                <button
                  onClick={() => setCurrentPage("cases")}
                  className="flex items-center gap-2 text-[#666666] hover:text-[#111111] mb-8 transition-colors"
                >
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <path d="M13 8H3M3 8L8 13M3 8L8 3" stroke="currentColor" strokeWidth="1" strokeOpacity="0.6" />
                  </svg>
                  <span className="text-[14px]">Retour aux cases</span>
                </button>
                <div className="flex flex-wrap gap-2 mb-6">
                  {selectedProject.poles.map((pole) => (
                    <Badge
                      key={pole}
                      className="glass-surface px-4 py-2 rounded-[4px] mono text-[11px] text-[#666666] border-0"
                    >
                      {pole.toUpperCase()}
                    </Badge>
                  ))}
                </div>
                <h1 className="text-[#111111] font-['Space_Grotesk'] mb-4">
                  {selectedProject.title}
                </h1>
                <p className="text-[#666666] text-[20px]">{selectedProject.client}</p>
              </div>
            </div>
          </section>

          <div className="container mx-auto px-6 lg:px-12">
            {/* Context & Meta */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-16 mb-20">
              <div className="lg:col-span-2">
                <h3 className="text-[#111111] font-['Space_Grotesk'] mb-4">Contexte</h3>
                <p className="text-[#666666] leading-relaxed">{selectedProject.context}</p>
              </div>
              <div className="space-y-6">
                <div>
                  <div className="text-[#999999] text-[13px] mono mb-2">INDUSTRIE</div>
                  <div className="text-[#111111]">{selectedProject.industry}</div>
                </div>
                <div>
                  <div className="text-[#999999] text-[13px] mono mb-2">LIVRABLES</div>
                  <ul className="space-y-2">
                    {selectedProject.deliverables.map((item, i) => (
                      <li key={i} className="flex items-start gap-2 text-[#666666]">
                        <div className="w-1 h-1 bg-[#E01919] mt-2 flex-shrink-0 rounded-full"></div>
                        <span className="text-[15px]">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Challenge */}
            <div className="mb-20">
              <h3 className="text-[#111111] font-['Space_Grotesk'] mb-6">Défi</h3>
              <p className="text-[#666666] leading-relaxed max-w-3xl">{selectedProject.challenge}</p>
            </div>

            {/* Approach */}
            <div className="mb-20">
              <h3 className="text-[#111111] font-['Space_Grotesk'] mb-8">Approche</h3>
              <div className="space-y-6">
                {selectedProject.approach.map((step, i) => (
                  <div key={i} className="flex gap-6">
                    <div className="flex-shrink-0 w-10 h-10 bg-[#E01919] rounded-[4px] flex items-center justify-center">
                      <span className="mono text-white text-[14px]">{String(i + 1).padStart(2, '0')}</span>
                    </div>
                    <p className="text-[#666666] leading-relaxed pt-2">{step}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Results & KPIs */}
            <div className="mb-20 p-12 glass-surface rounded-[12px] grain-overlay light-leak-top">
              <h3 className="text-[#111111] font-['Space_Grotesk'] mb-8">Résultats</h3>
              <p className="text-[#666666] leading-relaxed mb-12 max-w-3xl">{selectedProject.results}</p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                <KPI value={selectedProject.kpi1} label={selectedProject.kpi1Label} variant="accent" />
                <KPI value={selectedProject.kpi2} label={selectedProject.kpi2Label} />
              </div>
            </div>

            {/* Stack (if applicable) */}
            {selectedProject.stack && (
              <div className="mb-20">
                <h3 className="text-[#111111] font-['Space_Grotesk'] mb-6">Stack technique</h3>
                <div className="flex flex-wrap gap-3">
                  {selectedProject.stack.map((tech) => (
                    <Badge
                      key={tech}
                      className="glass-surface text-[#666666] px-4 py-2 rounded-[4px] mono text-[12px] border-0"
                    >
                      {tech}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Next Project CTA */}
            <div className="border-t border-[#00000014] pt-12 flex justify-between items-center">
              <Button
                onClick={() => setCurrentPage("cases")}
                variant="outline"
                className="glass-surface text-[#111111] hover:bg-white/90 border-0 rounded-[4px]"
              >
                Voir tous les projets
              </Button>
              <Button
                onClick={() => handleNavigate("contact")}
                className="bg-[#E01919] hover:bg-[#111111] text-white rounded-[4px] pixel-wave transition-all duration-220"
              >
                Discutons de votre projet
              </Button>
            </div>
          </div>

          <div className="mt-20">
            <Footer />
          </div>
        </div>
      )}

      {/* SERVICES PAGE */}
      {currentPage === "services" && (
        <div ref={servicesRef} className="pt-32 pb-20 px-6 lg:px-12">
          <div className="container mx-auto">
            <button
              onClick={() => handleNavigate("home")}
              className="flex items-center gap-2 text-[#666666] hover:text-[#111111] mb-8 transition-colors"
            >
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <path d="M13 8H3M3 8L8 13M3 8L8 3" stroke="currentColor" strokeWidth="1" strokeOpacity="0.6" />
              </svg>
              <span className="text-[14px]">Retour</span>
            </button>

            <h1 className="text-[#111111] font-['Space_Grotesk'] mb-6">
              Nos services
            </h1>
            <p className="text-[#666666] max-w-3xl mb-20 text-[18px] leading-relaxed">
              Des prestations sur-mesure pour accompagner vos projets, du concept à la réalisation.
            </p>

            {/* Services Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
              <div className="p-8 glass-surface rounded-[12px] grain-overlay light-leak-top glass-hover">
                <div className="w-12 h-12 bg-[#E01919]/10 rounded-[8px] flex items-center justify-center mb-6">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" className="text-[#E01919]">
                    <rect x="3" y="3" width="7" height="7" stroke="currentColor" strokeWidth="1.5" opacity="0.8" />
                    <rect x="14" y="3" width="7" height="7" stroke="currentColor" strokeWidth="1.5" opacity="0.8" />
                    <rect x="3" y="14" width="7" height="7" stroke="currentColor" strokeWidth="1.5" opacity="0.8" />
                    <rect x="14" y="14" width="7" height="7" stroke="currentColor" strokeWidth="1.5" opacity="0.8" />
                  </svg>
                </div>
                <h3 className="text-[#111111] font-['Space_Grotesk'] mb-4">Graphisme</h3>
                <ul className="space-y-3 mb-6">
                  {["Identité visuelle", "Branding & rebranding", "Design système", "Packaging", "Direction artistique", "Print & digital"].map((item) => (
                    <li key={item} className="flex items-start gap-2 text-[#666666] text-[15px]">
                      <div className="w-1 h-1 bg-[#E01919] mt-2 rounded-full"></div>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-8 glass-surface rounded-[12px] grain-overlay light-leak-top glass-hover">
                <div className="w-12 h-12 bg-[#E01919]/10 rounded-[8px] flex items-center justify-center mb-6">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" className="text-[#E01919]">
                    <path d="M6 6L18 6M18 6L18 18M18 6L6 18" stroke="currentColor" strokeWidth="1.5" opacity="0.8" />
                    <rect x="3" y="3" width="18" height="18" stroke="currentColor" strokeWidth="1.5" opacity="0.8" />
                  </svg>
                </div>
                <h3 className="text-[#111111] font-['Space_Grotesk'] mb-4">Code</h3>
                <ul className="space-y-3 mb-6">
                  {["Sites vitrine", "E-commerce", "Applications web", "Applications mobile", "SaaS & plateformes", "Maintenance & support"].map((item) => (
                    <li key={item} className="flex items-start gap-2 text-[#666666] text-[15px]">
                      <div className="w-1 h-1 bg-[#E01919] mt-2 rounded-full"></div>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-8 glass-surface rounded-[12px] grain-overlay light-leak-top glass-hover">
                <div className="w-12 h-12 bg-[#E01919]/10 rounded-[8px] flex items-center justify-center mb-6">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" className="text-[#E01919]">
                    <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.5" opacity="0.8" />
                    <circle cx="12" cy="12" r="4" stroke="currentColor" strokeWidth="1.5" opacity="0.8" />
                    <circle cx="12" cy="12" r="1.5" fill="currentColor" opacity="0.8" />
                  </svg>
                </div>
                <h3 className="text-[#111111] font-['Space_Grotesk'] mb-4">Communication</h3>
                <ul className="space-y-3 mb-6">
                  {["Stratégie de contenu", "Social media", "Campagnes digitales", "Motion design", "Événementiel", "Content creation"].map((item) => (
                    <li key={item} className="flex items-start gap-2 text-[#666666] text-[15px]">
                      <div className="w-1 h-1 bg-[#E01919] mt-2 rounded-full"></div>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Packs */}
            <div>
              <h2 className="text-[#111111] font-['Space_Grotesk'] mb-12">Formules</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="p-10 glass-surface rounded-[12px] glass-hover grain-overlay">
                  <div className="mono text-[#E01919] text-[13px] tracking-widest mb-4">STARTER</div>
                  <h3 className="text-[#111111] font-['Space_Grotesk'] mb-4">Lancement</h3>
                  <p className="text-[#666666] mb-8 text-[15px]">
                    Pour les projets ciblés nécessitant une expertise ponctuelle.
                  </p>
                  <div className="text-[#111111] mb-2">À partir de 5k€</div>
                  <div className="text-[#999999] text-[14px] mb-8">Projet unique</div>
                  <Button className="w-full glass-surface hover:bg-white/90 text-[#111111] border-0 rounded-[4px]">
                    En savoir plus
                  </Button>
                </div>

                <div className="p-10 glass-surface-strong rounded-[12px] glass-hover grain-overlay light-leak-top relative border-2 border-[#E01919]">
                  <div className="absolute -top-3 left-8 bg-[#E01919] px-4 py-1 rounded-[4px] depth-shadow">
                    <span className="mono text-white text-[11px] tracking-wider">POPULAIRE</span>
                  </div>
                  <div className="mono text-[#E01919] text-[13px] tracking-widest mb-4">GROWTH</div>
                  <h3 className="text-[#111111] font-['Space_Grotesk'] mb-4">Croissance</h3>
                  <p className="text-[#666666] mb-8 text-[15px]">
                    Pour les entreprises en développement cherchant un partenaire sur la durée.
                  </p>
                  <div className="text-[#111111] mb-2">À partir de 15k€</div>
                  <div className="text-[#999999] text-[14px] mb-8">3-6 mois</div>
                  <Button className="w-full bg-[#E01919] hover:bg-[#111111] text-white rounded-[4px] pixel-wave transition-all duration-220">
                    En savoir plus
                  </Button>
                </div>

                <div className="p-10 glass-surface rounded-[12px] glass-hover grain-overlay">
                  <div className="mono text-[#E01919] text-[13px] tracking-widest mb-4">PREMIUM</div>
                  <h3 className="text-[#111111] font-['Space_Grotesk'] mb-4">Sur-mesure</h3>
                  <p className="text-[#666666] mb-8 text-[15px]">
                    Pour les projets d'envergure nécessitant une expertise complète.
                  </p>
                  <div className="text-[#111111] mb-2">Sur devis</div>
                  <div className="text-[#999999] text-[14px] mb-8">Long terme</div>
                  <Button className="w-full glass-surface hover:bg-white/90 text-[#111111] border-0 rounded-[4px]">
                    Nous contacter
                  </Button>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-20">
            <Footer />
          </div>
        </div>
      )}

      {/* CONTACT PAGE */}
      {currentPage === "contact" && (
        <div ref={contactRef} className="pt-32 pb-20 px-6 lg:px-12">
          <div className="container mx-auto max-w-5xl">
            <button
              onClick={() => handleNavigate("home")}
              className="flex items-center gap-2 text-[#666666] hover:text-[#111111] mb-8 transition-colors"
            >
              <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                <path d="M13 8H3M3 8L8 13M3 8L8 3" stroke="currentColor" strokeWidth="1" strokeOpacity="0.6" />
              </svg>
              <span className="text-[14px]">Retour</span>
            </button>

            <div className="mb-12 flex items-center gap-4">
              <img 
                src={logoImage} 
                alt="Skwer Studio" 
                className="h-40 w-auto"
                style={{ imageRendering: 'pixelated' }}
              />
            </div>
            
            <h1 className="text-[#111111] font-['Space_Grotesk'] mb-6">
              Discutons de votre projet
            </h1>
            <p className="text-[#666666] mb-16 text-[18px] leading-relaxed">
              Parlez-nous de vos ambitions. Nous reviendrons vers vous sous 24h pour échanger sur la meilleure façon de les concrétiser.
            </p>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
              {/* Form */}
              <div className="lg:col-span-2">
                <form className="space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="name" className="text-[#111111] mb-2 block">Nom complet</Label>
                      <Input
                        id="name"
                        placeholder="Jean Dupont"
                        className="glass-surface text-[#111111] rounded-[8px] h-12 focus:border-[#E01919] border-0"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email" className="text-[#111111] mb-2 block">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="jean@entreprise.com"
                        className="glass-surface text-[#111111] rounded-[8px] h-12 focus:border-[#E01919] border-0"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="company" className="text-[#111111] mb-2 block">Entreprise</Label>
                      <Input
                        id="company"
                        placeholder="Nom de l'entreprise"
                        className="glass-surface text-[#111111] rounded-[8px] h-12 focus:border-[#E01919] border-0"
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone" className="text-[#111111] mb-2 block">Téléphone (optionnel)</Label>
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="+33 6 12 34 56 78"
                        className="glass-surface text-[#111111] rounded-[8px] h-12 focus:border-[#E01919] border-0"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="project-type" className="text-[#111111] mb-2 block">Type de projet</Label>
                    <Select>
                      <SelectTrigger className="glass-surface text-[#111111] rounded-[8px] h-12 focus:border-[#E01919] border-0">
                        <SelectValue placeholder="Sélectionnez..." />
                      </SelectTrigger>
                      <SelectContent className="glass-surface-strong text-[#111111] border-[#00000014]">
                        <SelectItem value="branding">Identité & Branding</SelectItem>
                        <SelectItem value="web">Site web</SelectItem>
                        <SelectItem value="app">Application</SelectItem>
                        <SelectItem value="ecommerce">E-commerce</SelectItem>
                        <SelectItem value="communication">Communication</SelectItem>
                        <SelectItem value="multiple">Projet global</SelectItem>
                        <SelectItem value="other">Autre</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="budget" className="text-white mb-2 block">Budget estimé</Label>
                      <Select>
                        <SelectTrigger className="bg-[#1E1E1E] border-white/[0.08] text-white rounded-[4px] h-12">
                          <SelectValue placeholder="Sélectionnez..." />
                        </SelectTrigger>
                        <SelectContent className="bg-[#1E1E1E] border-white/[0.08] text-white">
                          <SelectItem value="5-10">5k - 10k€</SelectItem>
                          <SelectItem value="10-25">10k - 25k€</SelectItem>
                          <SelectItem value="25-50">25k - 50k€</SelectItem>
                          <SelectItem value="50+">50k€ +</SelectItem>
                          <SelectItem value="tbd">À définir</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="timeline" className="text-white mb-2 block">Délai souhaité</Label>
                      <Select>
                        <SelectTrigger className="bg-[#1E1E1E] border-white/[0.08] text-white rounded-[4px] h-12">
                          <SelectValue placeholder="Sélectionnez..." />
                        </SelectTrigger>
                        <SelectContent className="bg-[#1E1E1E] border-white/[0.08] text-white">
                          <SelectItem value="urgent">Urgent ({"<"} 1 mois)</SelectItem>
                          <SelectItem value="1-3">1-3 mois</SelectItem>
                          <SelectItem value="3-6">3-6 mois</SelectItem>
                          <SelectItem value="6+">6 mois +</SelectItem>
                          <SelectItem value="flexible">Flexible</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="message" className="text-[#111111] mb-2 block">Message</Label>
                    <Textarea
                      id="message"
                      placeholder="Parlez-nous de votre projet, vos objectifs, vos contraintes..."
                      rows={6}
                      className="glass-surface text-[#111111] rounded-[8px] focus:border-[#E01919] border-0 resize-none grain-overlay"
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-[#E01919] hover:bg-[#111111] text-white h-14 rounded-[4px] pixel-wave transition-all duration-220 depth-shadow"
                  >
                    Envoyer le message
                  </Button>
                </form>
              </div>

              {/* Contact Info */}
              <div className="space-y-8">
                <div className="p-8 bg-[#1E1E1E] border border-white/[0.08] rounded-[4px]">
                  <h3 className="text-white font-['Space_Grotesk'] mb-6">Contact direct</h3>
                  <div className="space-y-6">
                    <div>
                      <div className="text-white/60 text-[13px] mono mb-2">EMAIL</div>
                      <a href="mailto:hello@skwr-studio.com" className="text-white hover:text-[#E01919] transition-colors">
                        hello@skwr-studio.com
                      </a>
                    </div>
                    <div>
                      <div className="text-white/60 text-[13px] mono mb-2">TÉLÉPHONE</div>
                      <a href="tel:+33123456789" className="text-white hover:text-[#E01919] transition-colors">
                        +33 1 23 45 67 89
                      </a>
                    </div>
                    <div>
                      <div className="text-white/60 text-[13px] mono mb-2">ADRESSE</div>
                      <p className="text-white/80 text-[15px]">
                        75 Avenue Parmentier<br />
                        75011 Paris, France
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-8 bg-[#1E1E1E] border border-white/[0.08] rounded-[4px]">
                  <h3 className="text-white font-['Space_Grotesk'] mb-4">Horaires</h3>
                  <div className="space-y-3 text-[15px]">
                    <div className="flex justify-between">
                      <span className="text-white/60">Lun - Ven</span>
                      <span className="text-white">9h - 18h</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-white/60">Weekend</span>
                      <span className="text-white/60">Fermé</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-20">
            <Footer />
          </div>
        </div>
      )}
    </div>
  );
}
