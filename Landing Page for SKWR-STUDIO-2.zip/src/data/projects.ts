export interface Project {
  id: string;
  title: string;
  client: string;
  industry: string;
  poles: string[];
  deliverables: string[];
  kpi1: string;
  kpi2: string;
  kpi1Label: string;
  kpi2Label: string;
  image: string;
  context: string;
  challenge: string;
  approach: string[];
  results: string;
  stack?: string[];
}

export const projects: Project[] = [
  {
    id: "squarebrew",
    title: "SquareBrew",
    client: "SquareBrew Coffee",
    industry: "Food & Beverage",
    poles: ["Graphisme", "Code", "Communication"],
    deliverables: ["Identité", "Packaging", "Design système web", "Shopify", "Campagne lancement"],
    kpi1: "+42%",
    kpi1Label: "Conversion",
    kpi2: "+3.1×",
    kpi2Label: "Trafic organique",
    image: "https://images.unsplash.com/photo-1745131317419-964490d0fc4e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2ZmZWUlMjBicmFuZGluZyUyMG1vZGVybnxlbnwxfHx8fDE3NjE5MzUwNTR8MA&ixlib=rb-4.1.0&q=80&w=1080",
    context: "SquareBrew Coffee souhaitait se positionner comme une marque premium de café artisanal, avec une identité forte et un e-commerce performant.",
    challenge: "Créer une identité de marque cohérente qui reflète l'excellence du produit tout en développant une plateforme e-commerce optimisée pour la conversion.",
    approach: [
      "Développement d'une identité visuelle minimaliste avec un système de packaging modulaire",
      "Création d'un design système complet pour assurer la cohérence sur tous les points de contact",
      "Développement d'une boutique Shopify optimisée avec parcours d'achat fluide"
    ],
    results: "Le lancement a dépassé les objectifs avec une augmentation de 42% du taux de conversion et un triplement du trafic organique en 3 mois.",
    stack: ["Shopify", "React", "Tailwind CSS"]
  },
  {
    id: "monolithe",
    title: "Monolithe",
    client: "Monolithe Architecture",
    industry: "Architecture",
    poles: ["Graphisme"],
    deliverables: ["Logo modulaire", "Charte 64p", "Papeterie", "Signalétique"],
    kpi1: "+5",
    kpi1Label: "Appels d'offres/mois",
    kpi2: "100%",
    kpi2Label: "Satisfaction client",
    image: "https://images.unsplash.com/photo-1657587851234-a74cd8b4d447?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcmNoaXRlY3R1cmUlMjBibHVlcHJpbnQlMjBtaW5pbWFsfGVufDF8fHx8MTc2MTkzNTA1NHww&ixlib=rb-4.1.0&q=80&w=1080",
    context: "Cabinet d'architecture recherchant une identité visuelle qui reflète leur approche structurée et leur expertise en design contemporain.",
    challenge: "Créer un système d'identité modulaire capable de s'adapter aux différents contextes d'utilisation tout en conservant une forte reconnaissance.",
    approach: [
      "Conception d'un logo modulaire basé sur des formes géométriques pures",
      "Développement d'une charte graphique exhaustive de 64 pages",
      "Création d'un système de signalétique cohérent pour les espaces physiques"
    ],
    results: "L'identité a permis à Monolithe de se démarquer avec 5 nouveaux appels d'offres mensuels supplémentaires."
  },
  {
    id: "flare",
    title: "Flare",
    client: "Flare.io",
    industry: "Logiciel B2B",
    poles: ["Code", "Graphisme"],
    deliverables: ["Site Next.js", "Design système Figma", "Illustrations", "Blog", "Analytics"],
    kpi1: "-38%",
    kpi1Label: "Taux de rebond",
    kpi2: "+120",
    kpi2Label: "MQL/trimestre",
    image: "https://images.unsplash.com/photo-1616479050071-d7f68f25dde0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYWFzJTIwZGFzaGJvYXJkJTIwbGFwdG9wfGVufDF8fHx8MTc2MTkzNTA1NXww&ixlib=rb-4.1.0&q=80&w=1080",
    context: "Flare.io, plateforme SaaS B2B, avait besoin d'un site vitrine moderne pour accompagner sa croissance et générer des leads qualifiés.",
    challenge: "Concevoir une expérience utilisateur engageante tout en développant un site performant et évolutif.",
    approach: [
      "Création d'un design système complet dans Figma avec composants réutilisables",
      "Développement d'un site Next.js optimisé pour les performances et le SEO",
      "Intégration d'analytics pour suivre le parcours utilisateur et optimiser la conversion"
    ],
    results: "Réduction de 38% du taux de rebond et génération de 120 MQL supplémentaires par trimestre.",
    stack: ["Next.js", "TypeScript", "Tailwind CSS", "Vercel"]
  },
  {
    id: "novarun",
    title: "NovaRun",
    client: "NovaRun",
    industry: "Sport/Health",
    poles: ["Code"],
    deliverables: ["UX flows", "UI kit", "React Native", "Onboarding", "Empty states"],
    kpi1: "34%",
    kpi1Label: "Rétention J7",
    kpi2: "4.6/5",
    kpi2Label: "Note App Store",
    image: "https://images.unsplash.com/photo-1580983703451-bf6bb44a9917?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2JpbGUlMjBmaXRuZXNzJTIwYXBwfGVufDF8fHx8MTc2MTkxMDgyN3ww&ixlib=rb-4.1.0&q=80&w=1080",
    context: "Application mobile de coaching sportif recherchant un MVP performant pour valider son concept auprès des premiers utilisateurs.",
    challenge: "Créer une expérience utilisateur fluide et motivante dès le premier lancement, avec un onboarding efficace.",
    approach: [
      "Conception de flows UX optimisés pour minimiser les frictions",
      "Développement d'un UI kit cohérent et accessible",
      "Création d'états vides engageants pour guider l'utilisateur"
    ],
    results: "34% de rétention à J7, dépassant les benchmarks du secteur fitness.",
    stack: ["React Native", "Expo", "TypeScript"]
  },
  {
    id: "musea",
    title: "Musea",
    client: "Musée des Passages",
    industry: "Culture",
    poles: ["Graphisme", "Communication"],
    deliverables: ["Affiche", "Catalogue", "Signalétique", "Microsite événement"],
    kpi1: "18k",
    kpi1Label: "Visiteurs",
    kpi2: "6",
    kpi2Label: "Semaines",
    image: "https://images.unsplash.com/photo-1706665714936-3211c96474c8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXNldW0lMjBleGhpYml0aW9uJTIwYXJ0fGVufDF8fHx8MTc2MTg1NDk3Nnww&ixlib=rb-4.1.0&q=80&w=1080",
    context: "Scénographie et identité visuelle pour une exposition temporaire sur les passages parisiens.",
    challenge: "Créer une identité visuelle forte qui attire les visiteurs tout en respectant l'identité du musée.",
    approach: [
      "Conception d'affiches grand format avec typographie expressive",
      "Création d'un catalogue éditorial de 120 pages",
      "Développement d'un microsite événementiel pour prolonger l'expérience"
    ],
    results: "18 000 visiteurs sur 6 semaines, dépassant les prévisions initiales de 40%."
  },
  {
    id: "parallele",
    title: "Parallèle",
    client: "Parallèle Magazine",
    industry: "Média",
    poles: ["Graphisme"],
    deliverables: ["Direction artistique", "Shooting 2 jours", "Retouches", "Maquette éditoriale"],
    kpi1: "+30%",
    kpi1Label: "Abonnements numériques",
    kpi2: "12",
    kpi2Label: "Pages éditoriales",
    image: "https://images.unsplash.com/photo-1626722850409-004d2774ae8e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWdhemluZSUyMGVkaXRvcmlhbCUyMHBob3RvZ3JhcGh5fGVufDF8fHx8MTc2MTkyODY5NXww&ixlib=rb-4.1.0&q=80&w=1080",
    context: "Direction photo et édition pour un numéro spécial du magazine Parallèle.",
    challenge: "Créer un univers visuel cohérent qui se démarque dans un secteur saturé.",
    approach: [
      "Direction artistique complète avec moodboard et références",
      "Shooting sur 2 jours avec équipe de 8 personnes",
      "Post-production et intégration dans une maquette éditoriale soignée"
    ],
    results: "Augmentation de 30% des abonnements numériques suite à la publication."
  },
  {
    id: "loop",
    title: "Loop Market",
    client: "Loop",
    industry: "Circular Retail",
    poles: ["Graphisme", "Communication"],
    deliverables: ["Logo", "Pack social", "Motion 6s", "Toolkit UGC"],
    kpi1: "+280%",
    kpi1Label: "Reach",
    kpi2: "-22%",
    kpi2Label: "CPC",
    image: "https://images.unsplash.com/photo-1711400385482-ffb5f7a19fcf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZXRhaWwlMjBzdG9yZSUyMGRlc2lnbnxlbnwxfHx8fDE3NjE4MzUwNjJ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    context: "Marketplace d'économie circulaire nécessitant une identité et une stratégie social media impactantes.",
    challenge: "Se démarquer dans l'univers encombré du retail durable avec une communication authentique.",
    approach: [
      "Création d'une identité visuelle moderne et accessible",
      "Développement d'un pack social complet avec templates adaptés",
      "Production de contenus motion courts et percutants"
    ],
    results: "Reach multiplié par 2.8 et réduction de 22% du coût par clic."
  },
  {
    id: "cobalt",
    title: "Cobalt",
    client: "Cobalt Energy",
    industry: "Energie",
    poles: ["Code"],
    deliverables: ["Webapp Next.js", "Charts Recharts", "Auth", "Rôles"],
    kpi1: "-40%",
    kpi1Label: "Temps de reporting",
    kpi2: "8",
    kpi2Label: "Rôles utilisateurs",
    image: "https://images.unsplash.com/photo-1635183607544-bf69187cc310?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbmVyZ3klMjBkYXNoYm9hcmQlMjBzY3JlZW58ZW58MXx8fHwxNzYxOTM1MDU4fDA&ixlib=rb-4.1.0&q=80&w=1080",
    context: "Développement d'un tableau de bord pour la gestion et le suivi de production énergétique.",
    challenge: "Créer une interface intuitive capable de gérer de gros volumes de données avec différents niveaux d'accès.",
    approach: [
      "Architecture d'une webapp Next.js avec SSR pour les performances",
      "Intégration de charts interactifs avec Recharts",
      "Système d'authentification et de rôles granulaires"
    ],
    results: "Réduction de 40% du temps de reporting pour les équipes opérationnelles.",
    stack: ["Next.js", "TypeScript", "Recharts", "PostgreSQL"]
  },
  {
    id: "radian",
    title: "Radian",
    client: "Radian Studio",
    industry: "Design",
    poles: ["Graphisme", "Code"],
    deliverables: ["Identité", "Site headless (Sanity)", "Cas animés"],
    kpi1: "+3",
    kpi1Label: "Contrats >50k€/an",
    kpi2: "2.4s",
    kpi2Label: "Temps de chargement",
    image: "https://images.unsplash.com/photo-1510074377623-8cf13fb86c08?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZXNpZ24lMjBzdHVkaW8lMjB3b3Jrc3BhY2V8ZW58MXx8fHwxNzYxODg0OTAyfDA&ixlib=rb-4.1.0&q=80&w=1080",
    context: "Studio de design recherchant une refonte complète pour refléter leur évolution et attirer des clients premium.",
    challenge: "Créer un site performant avec un CMS flexible pour gérer facilement les cas d'études.",
    approach: [
      "Refonte de l'identité de marque avec un système visuel cohérent",
      "Développement d'un site headless avec Sanity pour une gestion de contenu optimale",
      "Animations subtiles sur les cas d'études pour mettre en valeur le travail"
    ],
    results: "3 nouveaux contrats supérieurs à 50k€ signés dans les 6 mois suivant le lancement.",
    stack: ["Next.js", "Sanity", "Motion/React"]
  },
  {
    id: "klin",
    title: "Klin",
    client: "Klin",
    industry: "Hygiène",
    poles: ["Graphisme"],
    deliverables: ["Architecture de gamme", "Pictos 24px", "Fiches PLV"],
    kpi1: "15",
    kpi1Label: "Références produits",
    kpi2: "+25%",
    kpi2Label: "Visibilité linéaire",
    image: "https://images.unsplash.com/photo-1577997352779-c4db787d35c6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9kdWN0JTIwcGFja2FnaW5nJTIwbWluaW1hbHxlbnwxfHx8fDE3NjE4OTg1Nzh8MA&ixlib=rb-4.1.0&q=80&w=1080",
    context: "Marque de produits d'hygiène nécessitant un système de packaging cohérent pour sa gamme complète.",
    challenge: "Créer une architecture visuelle claire permettant aux consommateurs de naviguer facilement entre les références.",
    approach: [
      "Développement d'une architecture de gamme avec code couleur",
      "Création d'un système d'icônes 24px minimal et lisible",
      "Design de fiches PLV pour optimiser la présence en linéaire"
    ],
    results: "15 références harmonisées et +25% de visibilité en linéaire."
  },
  {
    id: "arpege",
    title: "Arpège",
    client: "Festival Arpège",
    industry: "Event",
    poles: ["Graphisme", "Communication"],
    deliverables: ["Affiche", "Plan de scène", "Écrans LED", "Stories", "Pass"],
    kpi1: "97%",
    kpi1Label: "Taux de remplissage",
    kpi2: "12k",
    kpi2Label: "Impressions sociales",
    image: "https://images.unsplash.com/photo-1727096857692-e9dadf2bc92e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXNpYyUyMGZlc3RpdmFsJTIwc3RhZ2V8ZW58MXx8fHwxNzYxODkyOTI1fDA&ixlib=rb-4.1.0&q=80&w=1080",
    context: "Festival de musique émergent recherchant une identité visuelle forte pour sa 3ème édition.",
    challenge: "Créer un système visuel déclinable sur tous les supports physiques et digitaux de l'événement.",
    approach: [
      "Conception d'une identité événementielle avec typographie expressive",
      "Habillage des écrans LED et signalétique sur site",
      "Campagne social media avec templates stories et posts"
    ],
    results: "97% de taux de remplissage et forte viralité sur les réseaux sociaux."
  },
  {
    id: "easyco",
    title: "EasyCo",
    client: "EasyCo",
    industry: "Immobilier/Coliving",
    poles: ["Code", "Graphisme"],
    deliverables: ["Prototype Figma", "Landing conversion", "Illustrations 3D"],
    kpi1: "6.8%",
    kpi1Label: "Taux de conversion lead",
    kpi2: "450",
    kpi2Label: "Leads/mois",
    image: "https://images.unsplash.com/photo-1641910177671-4c75efb5383c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyZWFsJTIwZXN0YXRlJTIwbW9kZXJufGVufDF8fHx8MTc2MTgyNjM1MHww&ixlib=rb-4.1.0&q=80&w=1080",
    context: "Plateforme de coliving cherchant à valider son concept avec une landing page performante.",
    challenge: "Créer une landing page qui convertit tout en testant rapidement les messages et visuels.",
    approach: [
      "Prototypage rapide dans Figma avec tests utilisateurs",
      "Développement d'une landing optimisée pour la conversion",
      "Création d'illustrations 3D légères pour illustrer les espaces"
    ],
    results: "Taux de conversion de 6.8% générant 450 leads qualifiés par mois.",
    stack: ["React", "Tailwind CSS", "Framer"]
  },
  {
    id: "ateliernord",
    title: "Atelier Nord",
    client: "Atelier Nord",
    industry: "Art & Craft",
    poles: ["Graphisme"],
    deliverables: ["Monogramme pixel", "Catalogue", "Portfolio statique"],
    kpi1: "84",
    kpi1Label: "Pages catalogue",
    kpi2: "+60%",
    kpi2Label: "Demandes de devis",
    image: "https://images.unsplash.com/photo-1628586431263-44040b966252?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcnRpc3QlMjBzdHVkaW8lMjBjcmFmdHxlbnwxfHx8fDE3NjE5MzUwNTl8MA&ixlib=rb-4.1.0&q=80&w=1080",
    context: "Atelier de création artisanale souhaitant professionnaliser sa communication visuelle.",
    challenge: "Créer une identité qui respecte l'authenticité artisanale tout en apportant une touche contemporaine.",
    approach: [
      "Création d'un monogramme pixel subtil",
      "Conception d'un catalogue de 84 pages mettant en valeur les créations",
      "Développement d'un portfolio statique élégant"
    ],
    results: "+60% de demandes de devis suite au lancement du nouveau catalogue."
  },
  {
    id: "flux",
    title: "Flux",
    client: "Flux Mobility",
    industry: "Mobilité",
    poles: ["Communication"],
    deliverables: ["Calendrier 3 mois", "Templates Figma", "Motion 9:16", "Guidelines tonales"],
    kpi1: "+12k",
    kpi1Label: "Abonnés en 90j",
    kpi2: "4.2%",
    kpi2Label: "Taux d'engagement",
    image: "https://images.unsplash.com/photo-1690437767987-34914f947075?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2JpbGl0eSUyMGVsZWN0cmljJTIwdmVoaWNsZXxlbnwxfHx8fDE3NjE5MzUwNTl8MA&ixlib=rb-4.1.0&q=80&w=1080",
    context: "Startup de mobilité électrique cherchant à construire sa présence social media de zéro.",
    challenge: "Créer une stratégie de contenu cohérente et scalable pour les 3 premiers mois.",
    approach: [
      "Définition d'une ligne éditoriale et tonalité de marque",
      "Création de templates Figma pour autonomiser l'équipe",
      "Production de contenus motion courts au format stories"
    ],
    results: "12 000 nouveaux abonnés en 90 jours avec un taux d'engagement de 4.2%."
  }
];
