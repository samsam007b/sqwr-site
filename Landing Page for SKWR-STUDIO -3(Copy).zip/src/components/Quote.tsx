interface QuoteProps {
  text: string;
  author: string;
  role: string;
}

export function Quote({ text, author, role }: QuoteProps) {
  return (
    <div className="relative p-12 glass rounded-lg">
      {/* Quote mark */}
      <div className="absolute top-8 left-8 w-10 h-10 flex items-center justify-center">
        <div className="w-8 h-8 border-l-2 border-t-2 border-[#E01919]"></div>
      </div>

      <div className="pl-8">
        <p className="text-[#111111] mb-8 italic text-[1.125rem] leading-relaxed font-light">
          {text}
        </p>
        <div className="flex items-center gap-4">
          <div className="w-1 h-10 bg-[#E01919]"></div>
          <div>
            <div className="text-[#111111] font-['Space_Grotesk'] font-normal mb-1">
              {author}
            </div>
            <div className="text-[#666666] text-[14px]">{role}</div>
          </div>
        </div>
      </div>
    </div>
  );
}
