interface PoleCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

export function PoleCard({ icon, title, description }: PoleCardProps) {
  return (
    <div className="group p-12 glass rounded-lg hover-lift transition-all duration-300">
      {/* Icon */}
      <div className="w-16 h-16 mb-8 glass-subtle rounded-lg flex items-center justify-center group-hover:bg-[#E01919]/5 transition-colors duration-300">
        <div className="text-[#E01919]">{icon}</div>
      </div>

      {/* Content */}
      <h3 className="text-[#111111] font-['Space_Grotesk'] mb-4 font-normal text-[1.5rem]">
        {title}
      </h3>
      <p className="text-[#666666] text-[1rem] leading-relaxed mb-8">
        {description}
      </p>

      {/* Hover indicator */}
      <div className="flex items-center gap-3 text-[#999999] group-hover:text-[#E01919] transition-colors duration-200">
        <span className="text-[12px] mono tracking-wider">DÉCOUVRIR</span>
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
          <path
            d="M3 9H15M15 9L9 3M15 9L9 15"
            stroke="currentColor"
            strokeWidth="1.5"
          />
        </svg>
      </div>
    </div>
  );
}
