import { Badge } from "./ui/badge";

interface ProjectCardProps {
  image: string;
  title: string;
  client: string;
  poles: string[];
  result: string;
  size?: "small" | "medium" | "large";
  onClick?: () => void;
}

export function ProjectCard({
  image,
  title,
  client,
  poles,
  result,
  size = "medium",
  onClick,
}: ProjectCardProps) {
  const sizeClasses = {
    small: "h-[420px]",
    medium: "h-[520px]",
    large: "h-[640px]",
  };

  return (
    <button
      onClick={onClick}
      className={`group relative ${sizeClasses[size]} w-full overflow-hidden rounded-lg text-left hover-lift glitch-hover`}
    >
      {/* Image */}
      <div className="absolute inset-0 overflow-hidden">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.02]"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-white/95 via-white/40 to-transparent"></div>
      </div>

      {/* Glass overlay bottom */}
      <div className="absolute bottom-0 left-0 right-0 glass-subtle border-t border-white/30">
        <div className="p-8">
          {/* Tags */}
          <div className="flex flex-wrap gap-2 mb-4">
            {poles.map((pole) => (
              <Badge
                key={pole}
                variant="outline"
                className="border-[#E6E6E6] text-[#666666] bg-white/60 backdrop-blur-sm px-3 py-1 rounded-md mono text-[10px] tracking-wider"
              >
                {pole.toUpperCase()}
              </Badge>
            ))}
          </div>

          {/* Title & Client */}
          <h3 className="font-['Space_Grotesk'] mb-2 text-[#111111] group-hover:text-[#E01919] transition-colors duration-200 font-normal">
            {title}
          </h3>
          <p className="text-[#666666] mb-3 text-[15px]">{client}</p>

          {/* Result */}
          <div className="flex items-center gap-2">
            <div className="w-1 h-1 bg-[#E01919] rounded-full"></div>
            <span className="text-[#999999] text-[13px]">{result}</span>
          </div>
        </div>
      </div>

      {/* Hover indicator */}
      <div className="absolute top-6 right-6 w-10 h-10 glass-subtle rounded-lg flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-200">
        <svg
          width="14"
          height="14"
          viewBox="0 0 14 14"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path
            d="M1 13L13 1M13 1H1M13 1V13"
            stroke="#111111"
            strokeWidth="1.5"
          />
        </svg>
      </div>
    </button>
  );
}
