interface ProcessStepProps {
  number: string;
  title: string;
  description: string;
}

export function ProcessStep({ number, title, description }: ProcessStepProps) {
  return (
    <div className="flex flex-col gap-8">
      {/* Number */}
      <div className="flex items-center gap-6">
        <div className="w-14 h-14 bg-[#E01919] flex items-center justify-center rounded-lg transition-transform duration-200 hover:scale-105">
          <span className="font-['JetBrains_Mono'] text-white text-[15px]">{number}</span>
        </div>
        <div className="flex-1 h-[1px] bg-[#E6E6E6]"></div>
      </div>

      {/* Content */}
      <div>
        <h4 className="text-[#111111] font-['Space_Grotesk'] mb-4 font-normal text-[1.5rem]">
          {title}
        </h4>
        <p className="text-[#666666] text-[1rem] leading-relaxed">
          {description}
        </p>
      </div>
    </div>
  );
}
