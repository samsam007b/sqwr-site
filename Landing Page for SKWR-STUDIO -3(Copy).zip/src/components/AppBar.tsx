import { useState, useEffect } from "react";
import { Button } from "./ui/button";

interface AppBarProps {
  onNavigate?: (section: string) => void;
}

export function AppBar({ onNavigate }: AppBarProps) {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleNavClick = (section: string) => {
    if (onNavigate) {
      onNavigate(section);
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "glass" : "bg-transparent"
      }`}
    >
      <div className="container mx-auto px-6 lg:px-12 max-w-[1440px]">
        <div className="flex items-center justify-between h-24">
          {/* Logo */}
          <button
            onClick={() => handleNavClick("home")}
            className="flex items-center gap-3 group"
          >
            <div className="w-8 h-8 bg-[#E01919] flex items-center justify-center transition-transform duration-200 group-hover:scale-105">
              <div className="w-4 h-4 border-2 border-white"></div>
            </div>
            <span className="font-['Space_Grotesk'] tracking-tight text-[#111111] font-normal">
              SKWR<span className="text-[#E01919]">‑</span>STUDIO
            </span>
          </button>

          {/* Navigation */}
          <nav className="hidden md:flex items-center gap-12">
            {["Cases", "Services", "Studio", "Contact"].map((item) => (
              <button
                key={item}
                onClick={() => handleNavClick(item.toLowerCase())}
                className="relative text-[#666666] hover:text-[#111111] transition-colors duration-200 group text-[15px]"
              >
                <span>{item}</span>
                <span className="absolute -bottom-1 left-0 w-0 h-[1px] bg-[#E01919] group-hover:w-full transition-all duration-300"></span>
              </button>
            ))}
          </nav>

          {/* CTA */}
          <Button
            onClick={() => handleNavClick("contact")}
            className="glass-subtle hover:bg-[#111111] hover:text-white text-[#111111] px-6 h-11 rounded-lg border-0 transition-all duration-200"
          >
            Démarrer un projet
          </Button>
        </div>
      </div>
    </header>
  );
}
