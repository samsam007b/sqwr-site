export function Footer() {
  return (
    <footer className="glass-strong border-t border-white/30 mt-48">
      <div className="container mx-auto px-6 lg:px-12 max-w-[1440px]">
        {/* Main footer */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 py-24">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 bg-[#E01919] flex items-center justify-center">
                <div className="w-5 h-5 border-2 border-white"></div>
              </div>
              <span className="font-['Space_Grotesk'] text-[18px] text-[#111111] font-normal">
                SKWR<span className="text-[#E01919]">‑</span>STUDIO
              </span>
            </div>
            <p className="text-[#666666] max-w-md mb-8 text-[15px] leading-relaxed">
              Agence familiale premium dédiée au design, au code et à la communication. 
              Nous transformons vos ambitions en réalisations d'exception.
            </p>
            <div className="flex items-center gap-4">
              <a
                href="#"
                className="w-11 h-11 glass-subtle rounded-lg flex items-center justify-center hover:bg-[#E01919] hover:text-white transition-all duration-200"
              >
                <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z" />
                </svg>
              </a>
              <a
                href="#"
                className="w-11 h-11 glass-subtle rounded-lg flex items-center justify-center hover:bg-[#E01919] hover:text-white transition-all duration-200"
              >
                <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6zM2 9h4v12H2z" />
                  <circle cx="4" cy="4" r="2" />
                </svg>
              </a>
              <a
                href="#"
                className="w-11 h-11 glass-subtle rounded-lg flex items-center justify-center hover:bg-[#E01919] hover:text-white transition-all duration-200"
              >
                <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
                  <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
                  <path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37zm1.5-4.87h.01" />
                </svg>
              </a>
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="font-['Space_Grotesk'] text-[#111111] mb-6 font-normal">Navigation</h4>
            <ul className="space-y-4">
              {["Cases", "Services", "Studio", "Contact"].map((item) => (
                <li key={item}>
                  <a
                    href={`#${item.toLowerCase()}`}
                    className="text-[#666666] hover:text-[#E01919] transition-colors text-[15px]"
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-['Space_Grotesk'] text-[#111111] mb-6 font-normal">Contact</h4>
            <ul className="space-y-4">
              <li>
                <a
                  href="mailto:hello@skwr-studio.com"
                  className="text-[#666666] hover:text-[#E01919] transition-colors text-[15px]"
                >
                  hello@skwr-studio.com
                </a>
              </li>
              <li>
                <a
                  href="tel:+33123456789"
                  className="text-[#666666] hover:text-[#E01919] transition-colors text-[15px]"
                >
                  +33 1 23 45 67 89
                </a>
              </li>
              <li className="text-[#666666] text-[15px]">
                Paris, France
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-[#E6E6E6] py-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-[#999999] text-[12px] mono tracking-wide">
            © 2025 SKWR-STUDIO. TOUS DROITS RÉSERVÉS.
          </p>
          <div className="flex items-center gap-8">
            <a href="#" className="text-[#999999] hover:text-[#111111] transition-colors text-[12px] mono tracking-wide">
              MENTIONS LÉGALES
            </a>
            <a href="#" className="text-[#999999] hover:text-[#111111] transition-colors text-[12px] mono tracking-wide">
              CONFIDENTIALITÉ
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
