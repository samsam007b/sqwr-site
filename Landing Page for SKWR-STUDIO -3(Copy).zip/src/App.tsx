import { useState, useRef, useEffect } from "react";
import { AppBar } from "./components/AppBar";
import { ProjectCard } from "./components/ProjectCard";
import { KPI } from "./components/KPI";
import { Quote } from "./components/Quote";
import { ProcessStep } from "./components/ProcessStep";
import { PoleCard } from "./components/PoleCard";
import { Footer } from "./components/Footer";
import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";
import { Textarea } from "./components/ui/textarea";
import { Label } from "./components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./components/ui/select";
import { Badge } from "./components/ui/badge";
import { projects, type Project } from "./data/projects";

type Page = "home" | "cases" | "case-detail" | "services" | "studio" | "contact";

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>("home");
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [filterPole, setFilterPole] = useState<string>("all");

  const homeRef = useRef<HTMLDivElement>(null);
  const casesRef = useRef<HTMLDivElement>(null);
  const servicesRef = useRef<HTMLDivElement>(null);
  const studioRef = useRef<HTMLDivElement>(null);
  const contactRef = useRef<HTMLDivElement>(null);

  const handleNavigate = (section: string) => {
    if (section === "home") {
      setCurrentPage("home");
      window.scrollTo({ top: 0, behavior: "smooth" });
    } else {
      setCurrentPage(section as Page);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const handleProjectClick = (project: Project) => {
    setSelectedProject(project);
    setCurrentPage("case-detail");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const featuredProjects = projects.slice(0, 6);
  const filteredProjects = filterPole === "all" 
    ? projects 
    : projects.filter(p => p.poles.includes(filterPole));

  return (
    <div className="min-h-screen bg-[#FAFAF8] text-[#111111]">
      <AppBar onNavigate={handleNavigate} />

      {/* HOME PAGE */}
      {currentPage === "home" && (
        <div ref={homeRef} className="page-transition">
          {/* Hero Section */}
          <section className="min-h-screen flex items-center justify-center px-6 lg:px-12 pt-24 relative overflow-hidden">
            <div className="container mx-auto max-w-[1440px] relative z-10">
              <div className="max-w-6xl mx-auto text-center">
                <h1 className="text-[#111111] mb-12 font-['Space_Grotesk'] font-light">
                  Transformer vos <span className="text-[#E01919]">ambitions</span><br />en réalisations d'exception
                </h1>
                <p className="text-[#666666] max-w-3xl mx-auto mb-16 text-[1.25rem] leading-relaxed font-light">
                  Agence familiale premium dédiée au design, au développement et à la communication. 
                  Nous créons des expériences qui marquent les esprits.
                </p>
                <div className="flex flex-wrap gap-4 justify-center">
                  <Button
                    onClick={() => handleNavigate("contact")}
                    className="bg-[#111111] hover:bg-[#E01919] text-white px-10 h-14 rounded-lg transition-all duration-300"
                  >
                    Démarrer un projet
                  </Button>
                  <Button
                    onClick={() => handleNavigate("cases")}
                    className="glass-subtle hover:bg-[#111111] hover:text-white text-[#111111] px-10 h-14 rounded-lg transition-all duration-300"
                  >
                    Voir nos réalisations
                  </Button>
                </div>
              </div>
            </div>
          </section>

          {/* 3 Pôles */}
          <section className="py-48 px-6 lg:px-12 section-separator">
            <div className="container mx-auto max-w-[1440px]">
              <div className="mb-24 text-center">
                <span className="text-[#E01919] mono text-[11px] tracking-[0.2em]">NOS PÔLES</span>
                <h2 className="text-[#111111] font-['Space_Grotesk'] mt-6 font-light">
                  Trois expertises,<br />une vision commune
                </h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <PoleCard
                  icon={
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                      <rect x="4" y="4" width="10" height="10" stroke="currentColor" strokeWidth="2" />
                      <rect x="18" y="4" width="10" height="10" stroke="currentColor" strokeWidth="2" />
                      <rect x="4" y="18" width="10" height="10" stroke="currentColor" strokeWidth="2" />
                      <rect x="18" y="18" width="10" height="10" stroke="currentColor" strokeWidth="2" />
                    </svg>
                  }
                  title="Graphisme"
                  description="Identités visuelles, design système, packaging et direction artistique. Nous créons des univers visuels cohérents et mémorables."
                />
                <PoleCard
                  icon={
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                      <path d="M8 8L24 8M24 8L24 24M24 8L8 24" stroke="currentColor" strokeWidth="2" />
                      <rect x="4" y="4" width="24" height="24" stroke="currentColor" strokeWidth="2" />
                    </svg>
                  }
                  title="Code"
                  description="Sites web, applications, plateformes SaaS et e-commerce. Développement sur-mesure avec les technologies les plus performantes."
                />
                <PoleCard
                  icon={
                    <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
                      <circle cx="16" cy="16" r="12" stroke="currentColor" strokeWidth="2" />
                      <circle cx="16" cy="16" r="6" stroke="currentColor" strokeWidth="2" />
                      <circle cx="16" cy="16" r="2" fill="currentColor" />
                    </svg>
                  }
                  title="Communication"
                  description="Stratégie de contenu, social media, campagnes et événementiel. Nous amplifions votre message auprès de vos audiences."
                />
              </div>
            </div>
          </section>

          {/* Cases Featured */}
          <section className="py-48 px-6 lg:px-12">
            <div className="container mx-auto max-w-[1440px]">
              <div className="flex justify-between items-end mb-24">
                <div>
                  <span className="text-[#E01919] mono text-[11px] tracking-[0.2em]">RÉALISATIONS</span>
                  <h2 className="text-[#111111] font-['Space_Grotesk'] mt-6 font-light">
                    Projets sélectionnés
                  </h2>
                </div>
                <Button
                  onClick={() => handleNavigate("cases")}
                  className="text-[#666666] hover:text-[#E01919] hidden md:flex items-center gap-3 bg-transparent border-0 transition-colors"
                >
                  <span className="mono text-[11px] tracking-[0.2em]">VOIR TOUS</span>
                  <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                    <path d="M3 9H15M15 9L9 3M15 9L9 15" stroke="currentColor" strokeWidth="1.5" />
                  </svg>
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {featuredProjects.map((project, index) => (
                  <ProjectCard
                    key={project.id}
                    image={project.image}
                    title={project.title}
                    client={project.client}
                    poles={project.poles}
                    result={project.kpi1 + " " + project.kpi1Label}
                    size={index === 0 || index === 3 ? "large" : "medium"}
                    onClick={() => handleProjectClick(project)}
                  />
                ))}
              </div>
            </div>
          </section>

          {/* Process */}
          <section className="py-48 px-6 lg:px-12 section-separator">
            <div className="container mx-auto max-w-[1440px]">
              <div className="mb-24 text-center">
                <span className="text-[#E01919] mono text-[11px] tracking-[0.2em]">MÉTHODE</span>
                <h2 className="text-[#111111] font-['Space_Grotesk'] mt-6 font-light">
                  Notre approche
                </h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-16">
                <ProcessStep
                  number="01"
                  title="Écoute & Stratégie"
                  description="Nous commençons par comprendre vos enjeux, vos ambitions et votre ADN. Cette phase d'écoute nous permet de définir la stratégie créative la plus pertinente."
                />
                <ProcessStep
                  number="02"
                  title="Création & Développement"
                  description="Notre équipe conçoit et développe des solutions sur-mesure, en itérant avec vous à chaque étape pour garantir un résultat qui dépasse vos attentes."
                />
                <ProcessStep
                  number="03"
                  title="Lancement & Suivi"
                  description="Nous vous accompagnons dans le déploiement et restons à vos côtés pour mesurer les performances et optimiser en continu."
                />
              </div>
            </div>
          </section>

          {/* Preuves */}
          <section className="py-48 px-6 lg:px-12 glass-strong">
            <div className="container mx-auto max-w-[1440px]">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
                <div>
                  <span className="text-[#E01919] mono text-[11px] tracking-[0.2em]">RÉSULTATS</span>
                  <h2 className="text-[#111111] font-['Space_Grotesk'] mt-6 mb-16 font-light">
                    Des chiffres qui parlent
                  </h2>
                  <div className="grid grid-cols-2 gap-12">
                    <KPI value="50+" label="Projets livrés" variant="accent" />
                    <KPI value="98%" label="Satisfaction client" />
                    <KPI value="3.2×" label="ROI moyen" variant="accent" />
                    <KPI value="24h" label="Temps de réponse" />
                  </div>
                </div>
                <Quote
                  text="SKWR-STUDIO a su comprendre notre vision et la traduire en une identité visuelle forte qui nous différencie vraiment. L'équipe est réactive, créative et d'un professionnalisme exemplaire."
                  author="Marie Dubois"
                  role="CEO, SquareBrew Coffee"
                />
              </div>
            </div>
          </section>

          {/* Studio */}
          <section id="studio" ref={studioRef} className="py-48 px-6 lg:px-12">
            <div className="container mx-auto max-w-[1440px]">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
                <div className="relative h-[600px] rounded-xl overflow-hidden">
                  <img
                    src="https://images.unsplash.com/photo-1510074377623-8cf13fb86c08?w=1200&q=80"
                    alt="Studio"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <span className="text-[#E01919] mono text-[11px] tracking-[0.2em]">À PROPOS</span>
                  <h2 className="text-[#111111] font-['Space_Grotesk'] mt-6 mb-10 font-light">
                    Une agence familiale,<br />des valeurs fortes
                  </h2>
                  <p className="text-[#666666] mb-6 leading-relaxed text-[1.0625rem]">
                    Fondé en 2019, SKWR-STUDIO est né de la volonté de créer une agence à taille humaine, 
                    capable de combiner expertise technique, sensibilité créative et relation client privilégiée.
                  </p>
                  <p className="text-[#666666] mb-10 leading-relaxed text-[1.0625rem]">
                    Aujourd'hui, notre équipe de 8 personnes travaille avec des clients partout en France 
                    et à l'international, sur des projets qui ont du sens et de l'impact.
                  </p>
                  <Button
                    onClick={() => handleNavigate("contact")}
                    className="bg-[#111111] hover:bg-[#E01919] text-white px-10 h-14 rounded-lg transition-all duration-300"
                  >
                    Rencontrons-nous
                  </Button>
                </div>
              </div>
            </div>
          </section>

          <Footer />
        </div>
      )}

      {/* CASES LISTING PAGE */}
      {currentPage === "cases" && (
        <div ref={casesRef} className="pt-32 pb-20 px-6 lg:px-12 page-transition">
          <div className="container mx-auto max-w-[1440px]">
            {/* Header */}
            <div className="mb-24">
              <button
                onClick={() => handleNavigate("home")}
                className="flex items-center gap-2 text-[#666666] hover:text-[#111111] mb-12 transition-colors"
              >
                <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                  <path d="M15 9H3M3 9L9 15M3 9L9 3" stroke="currentColor" strokeWidth="1.5" />
                </svg>
                <span className="text-[15px]">Retour</span>
              </button>
              <h1 className="text-[#111111] font-['Space_Grotesk'] mb-8 font-light">
                Nos réalisations
              </h1>
              <p className="text-[#666666] max-w-3xl text-[1.125rem] leading-relaxed">
                Une sélection de projets qui illustrent notre approche et notre savoir-faire.
              </p>
            </div>

            {/* Filters */}
            <div className="flex flex-wrap gap-3 mb-16">
              {["all", "Graphisme", "Code", "Communication"].map((pole) => (
                <button
                  key={pole}
                  onClick={() => setFilterPole(pole)}
                  className={`px-6 py-3 rounded-lg border transition-all mono text-[11px] tracking-[0.15em] ${
                    filterPole === pole
                      ? "bg-[#111111] border-[#111111] text-white"
                      : "glass-subtle text-[#666666] hover:border-[#E01919]"
                  }`}
                >
                  {pole === "all" ? "TOUS" : pole.toUpperCase()}
                </button>
              ))}
            </div>

            {/* Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProjects.map((project) => (
                <ProjectCard
                  key={project.id}
                  image={project.image}
                  title={project.title}
                  client={project.client}
                  poles={project.poles}
                  result={project.kpi1 + " " + project.kpi1Label}
                  onClick={() => handleProjectClick(project)}
                />
              ))}
            </div>
          </div>
          <Footer />
        </div>
      )}

      {/* CASE DETAIL PAGE */}
      {currentPage === "case-detail" && selectedProject && (
        <div className="pt-32 pb-20 page-transition">
          {/* Hero */}
          <section className="relative h-[75vh] mb-32">
            <img
              src={selectedProject.image}
              alt={selectedProject.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-white via-white/40 to-transparent"></div>
            <div className="absolute inset-0 flex items-end">
              <div className="container mx-auto max-w-[1440px] px-6 lg:px-12 pb-20">
                <button
                  onClick={() => setCurrentPage("cases")}
                  className="flex items-center gap-2 text-[#666666] hover:text-[#111111] mb-12 transition-colors glass-subtle px-4 py-2 rounded-lg"
                >
                  <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                    <path d="M15 9H3M3 9L9 15M3 9L9 3" stroke="currentColor" strokeWidth="1.5" />
                  </svg>
                  <span className="text-[15px]">Retour aux cases</span>
                </button>
                <div className="flex flex-wrap gap-3 mb-8">
                  {selectedProject.poles.map((pole) => (
                    <Badge
                      key={pole}
                      className="glass-subtle text-[#111111] px-4 py-2 rounded-lg mono text-[10px] tracking-[0.15em]"
                    >
                      {pole.toUpperCase()}
                    </Badge>
                  ))}
                </div>
                <h1 className="text-[#111111] font-['Space_Grotesk'] mb-6 font-light">
                  {selectedProject.title}
                </h1>
                <p className="text-[#666666] text-[1.25rem]">{selectedProject.client}</p>
              </div>
            </div>
          </section>

          <div className="container mx-auto max-w-[1440px] px-6 lg:px-12">
            {/* Context & Meta */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-20 mb-32">
              <div className="lg:col-span-2">
                <h3 className="text-[#111111] font-['Space_Grotesk'] mb-6 font-normal">Contexte</h3>
                <p className="text-[#666666] leading-relaxed text-[1.0625rem]">{selectedProject.context}</p>
              </div>
              <div className="space-y-8">
                <div>
                  <div className="text-[#999999] text-[11px] mono mb-3 tracking-[0.15em]">INDUSTRIE</div>
                  <div className="text-[#111111]">{selectedProject.industry}</div>
                </div>
                <div>
                  <div className="text-[#999999] text-[11px] mono mb-3 tracking-[0.15em]">LIVRABLES</div>
                  <ul className="space-y-3">
                    {selectedProject.deliverables.map((item, i) => (
                      <li key={i} className="flex items-start gap-3 text-[#666666]">
                        <div className="w-1 h-1 bg-[#E01919] mt-2 flex-shrink-0 rounded-full"></div>
                        <span className="text-[15px]">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>

            {/* Challenge */}
            <div className="mb-32">
              <h3 className="text-[#111111] font-['Space_Grotesk'] mb-8 font-normal">Défi</h3>
              <p className="text-[#666666] leading-relaxed max-w-4xl text-[1.0625rem]">{selectedProject.challenge}</p>
            </div>

            {/* Approach */}
            <div className="mb-32">
              <h3 className="text-[#111111] font-['Space_Grotesk'] mb-12 font-normal">Approche</h3>
              <div className="space-y-8">
                {selectedProject.approach.map((step, i) => (
                  <div key={i} className="flex gap-8">
                    <div className="flex-shrink-0 w-12 h-12 bg-[#E01919] rounded-lg flex items-center justify-center">
                      <span className="mono text-white text-[14px]">{String(i + 1).padStart(2, '0')}</span>
                    </div>
                    <p className="text-[#666666] leading-relaxed pt-3 text-[1.0625rem]">{step}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Results & KPIs */}
            <div className="mb-32 p-16 glass rounded-xl">
              <h3 className="text-[#111111] font-['Space_Grotesk'] mb-10 font-normal">Résultats</h3>
              <p className="text-[#666666] leading-relaxed mb-16 max-w-4xl text-[1.0625rem]">{selectedProject.results}</p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-12">
                <KPI value={selectedProject.kpi1} label={selectedProject.kpi1Label} variant="accent" />
                <KPI value={selectedProject.kpi2} label={selectedProject.kpi2Label} />
              </div>
            </div>

            {/* Stack (if applicable) */}
            {selectedProject.stack && (
              <div className="mb-32">
                <h3 className="text-[#111111] font-['Space_Grotesk'] mb-8 font-normal">Stack technique</h3>
                <div className="flex flex-wrap gap-3">
                  {selectedProject.stack.map((tech) => (
                    <Badge
                      key={tech}
                      className="glass-subtle text-[#666666] px-5 py-2 rounded-lg mono text-[11px] tracking-[0.1em]"
                    >
                      {tech}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Next Project CTA */}
            <div className="section-separator pt-16 flex flex-col md:flex-row justify-between items-center gap-4">
              <Button
                onClick={() => setCurrentPage("cases")}
                className="glass-subtle text-[#111111] hover:bg-[#111111] hover:text-white rounded-lg px-8 h-14 transition-all duration-300"
              >
                Voir tous les projets
              </Button>
              <Button
                onClick={() => handleNavigate("contact")}
                className="bg-[#111111] hover:bg-[#E01919] text-white rounded-lg px-8 h-14 transition-all duration-300"
              >
                Discutons de votre projet
              </Button>
            </div>
          </div>

          <div className="mt-20">
            <Footer />
          </div>
        </div>
      )}

      {/* SERVICES PAGE */}
      {currentPage === "services" && (
        <div ref={servicesRef} className="pt-32 pb-20 px-6 lg:px-12 page-transition">
          <div className="container mx-auto max-w-[1440px]">
            <button
              onClick={() => handleNavigate("home")}
              className="flex items-center gap-2 text-[#666666] hover:text-[#111111] mb-12 transition-colors"
            >
              <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                <path d="M15 9H3M3 9L9 15M3 9L9 3" stroke="currentColor" strokeWidth="1.5" />
              </svg>
              <span className="text-[15px]">Retour</span>
            </button>

            <h1 className="text-[#111111] font-['Space_Grotesk'] mb-8 font-light">
              Nos services
            </h1>
            <p className="text-[#666666] max-w-4xl mb-32 text-[1.125rem] leading-relaxed">
              Des prestations sur-mesure pour accompagner vos projets, du concept à la réalisation.
            </p>

            {/* Services Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-32">
              <div className="p-12 glass rounded-xl hover-lift">
                <div className="w-14 h-14 bg-[#E01919]/5 rounded-lg flex items-center justify-center mb-8">
                  <svg width="28" height="28" viewBox="0 0 28 28" fill="none" className="text-[#E01919]">
                    <rect x="3" y="3" width="8" height="8" stroke="currentColor" strokeWidth="2" />
                    <rect x="17" y="3" width="8" height="8" stroke="currentColor" strokeWidth="2" />
                    <rect x="3" y="17" width="8" height="8" stroke="currentColor" strokeWidth="2" />
                    <rect x="17" y="17" width="8" height="8" stroke="currentColor" strokeWidth="2" />
                  </svg>
                </div>
                <h3 className="text-[#111111] font-['Space_Grotesk'] mb-6 font-normal text-[1.5rem]">Graphisme</h3>
                <ul className="space-y-3 mb-6">
                  {["Identité visuelle", "Branding & rebranding", "Design système", "Packaging", "Direction artistique", "Print & digital"].map((item) => (
                    <li key={item} className="flex items-start gap-3 text-[#666666] text-[15px]">
                      <div className="w-1 h-1 bg-[#E01919] mt-2 rounded-full"></div>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-12 glass rounded-xl hover-lift">
                <div className="w-14 h-14 bg-[#E01919]/5 rounded-lg flex items-center justify-center mb-8">
                  <svg width="28" height="28" viewBox="0 0 28 28" fill="none" className="text-[#E01919]">
                    <path d="M6 6L22 6M22 6L22 22M22 6L6 22" stroke="currentColor" strokeWidth="2" />
                    <rect x="3" y="3" width="22" height="22" stroke="currentColor" strokeWidth="2" />
                  </svg>
                </div>
                <h3 className="text-[#111111] font-['Space_Grotesk'] mb-6 font-normal text-[1.5rem]">Code</h3>
                <ul className="space-y-3 mb-6">
                  {["Sites vitrine", "E-commerce", "Applications web", "Applications mobile", "SaaS & plateformes", "Maintenance & support"].map((item) => (
                    <li key={item} className="flex items-start gap-3 text-[#666666] text-[15px]">
                      <div className="w-1 h-1 bg-[#E01919] mt-2 rounded-full"></div>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="p-12 glass rounded-xl hover-lift">
                <div className="w-14 h-14 bg-[#E01919]/5 rounded-lg flex items-center justify-center mb-8">
                  <svg width="28" height="28" viewBox="0 0 28 28" fill="none" className="text-[#E01919]">
                    <circle cx="14" cy="14" r="10" stroke="currentColor" strokeWidth="2" />
                    <circle cx="14" cy="14" r="5" stroke="currentColor" strokeWidth="2" />
                    <circle cx="14" cy="14" r="2" fill="currentColor" />
                  </svg>
                </div>
                <h3 className="text-[#111111] font-['Space_Grotesk'] mb-6 font-normal text-[1.5rem]">Communication</h3>
                <ul className="space-y-3 mb-6">
                  {["Stratégie de contenu", "Social media", "Campagnes digitales", "Motion design", "Événementiel", "Content creation"].map((item) => (
                    <li key={item} className="flex items-start gap-3 text-[#666666] text-[15px]">
                      <div className="w-1 h-1 bg-[#E01919] mt-2 rounded-full"></div>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Packs */}
            <div>
              <h2 className="text-[#111111] font-['Space_Grotesk'] mb-16 font-light text-[3rem]">Formules</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="p-12 glass rounded-xl hover-lift transition-all">
                  <div className="mono text-[#E01919] text-[11px] tracking-[0.2em] mb-4">STARTER</div>
                  <h3 className="text-[#111111] font-['Space_Grotesk'] mb-4 font-normal text-[1.5rem]">Lancement</h3>
                  <p className="text-[#666666] mb-10 text-[15px] leading-relaxed">
                    Pour les projets ciblés nécessitant une expertise ponctuelle.
                  </p>
                  <div className="text-[#111111] mb-2 font-['Space_Grotesk'] text-[1.5rem]">À partir de 5k€</div>
                  <div className="text-[#999999] text-[14px] mb-10">Projet unique</div>
                  <Button className="w-full glass-subtle hover:bg-[#111111] hover:text-white text-[#111111] rounded-lg h-12 transition-all duration-300">
                    En savoir plus
                  </Button>
                </div>

                <div className="p-12 glass-strong rounded-xl hover-lift relative border-2 border-[#E01919]/20">
                  <div className="absolute -top-3 left-8 bg-[#E01919] px-5 py-2 rounded-lg">
                    <span className="mono text-white text-[10px] tracking-[0.2em]">POPULAIRE</span>
                  </div>
                  <div className="mono text-[#E01919] text-[11px] tracking-[0.2em] mb-4">GROWTH</div>
                  <h3 className="text-[#111111] font-['Space_Grotesk'] mb-4 font-normal text-[1.5rem]">Croissance</h3>
                  <p className="text-[#666666] mb-10 text-[15px] leading-relaxed">
                    Pour les entreprises en développement cherchant un partenaire sur la durée.
                  </p>
                  <div className="text-[#111111] mb-2 font-['Space_Grotesk'] text-[1.5rem]">À partir de 15k€</div>
                  <div className="text-[#999999] text-[14px] mb-10">3-6 mois</div>
                  <Button className="w-full bg-[#E01919] hover:bg-[#111111] text-white rounded-lg h-12 transition-all duration-300">
                    En savoir plus
                  </Button>
                </div>

                <div className="p-12 glass rounded-xl hover-lift transition-all">
                  <div className="mono text-[#E01919] text-[11px] tracking-[0.2em] mb-4">PREMIUM</div>
                  <h3 className="text-[#111111] font-['Space_Grotesk'] mb-4 font-normal text-[1.5rem]">Sur-mesure</h3>
                  <p className="text-[#666666] mb-10 text-[15px] leading-relaxed">
                    Pour les projets d'envergure nécessitant une expertise complète.
                  </p>
                  <div className="text-[#111111] mb-2 font-['Space_Grotesk'] text-[1.5rem]">Sur devis</div>
                  <div className="text-[#999999] text-[14px] mb-10">Long terme</div>
                  <Button className="w-full glass-subtle hover:bg-[#111111] hover:text-white text-[#111111] rounded-lg h-12 transition-all duration-300">
                    Nous contacter
                  </Button>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-20">
            <Footer />
          </div>
        </div>
      )}

      {/* CONTACT PAGE */}
      {currentPage === "contact" && (
        <div ref={contactRef} className="pt-32 pb-20 px-6 lg:px-12 page-transition">
          <div className="container mx-auto max-w-6xl">
            <button
              onClick={() => handleNavigate("home")}
              className="flex items-center gap-2 text-[#666666] hover:text-[#111111] mb-12 transition-colors"
            >
              <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
                <path d="M15 9H3M3 9L9 15M3 9L9 3" stroke="currentColor" strokeWidth="1.5" />
              </svg>
              <span className="text-[15px]">Retour</span>
            </button>

            <h1 className="text-[#111111] font-['Space_Grotesk'] mb-8 font-light">
              Discutons de votre projet
            </h1>
            <p className="text-[#666666] mb-24 text-[1.125rem] leading-relaxed max-w-3xl">
              Parlez-nous de vos ambitions. Nous reviendrons vers vous sous 24h pour échanger sur la meilleure façon de les concrétiser.
            </p>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
              {/* Form */}
              <div className="lg:col-span-2">
                <form className="space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="name" className="text-[#111111] mb-3 block">Nom complet</Label>
                      <Input
                        id="name"
                        placeholder="Jean Dupont"
                        className="glass-subtle text-[#111111] placeholder:text-[#999999] rounded-lg h-14 focus:border-[#E01919]"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email" className="text-[#111111] mb-3 block">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="jean@entreprise.com"
                        className="glass-subtle text-[#111111] placeholder:text-[#999999] rounded-lg h-14 focus:border-[#E01919]"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="company" className="text-[#111111] mb-3 block">Entreprise</Label>
                      <Input
                        id="company"
                        placeholder="Nom de l'entreprise"
                        className="glass-subtle text-[#111111] placeholder:text-[#999999] rounded-lg h-14 focus:border-[#E01919]"
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone" className="text-[#111111] mb-3 block">Téléphone (optionnel)</Label>
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="+33 6 12 34 56 78"
                        className="glass-subtle text-[#111111] placeholder:text-[#999999] rounded-lg h-14 focus:border-[#E01919]"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="project-type" className="text-[#111111] mb-3 block">Type de projet</Label>
                    <Select>
                      <SelectTrigger className="glass-subtle text-[#111111] rounded-lg h-14 focus:border-[#E01919]">
                        <SelectValue placeholder="Sélectionnez..." />
                      </SelectTrigger>
                      <SelectContent className="glass-strong border-[#E6E6E6] text-[#111111]">
                        <SelectItem value="branding">Identité & Branding</SelectItem>
                        <SelectItem value="web">Site web</SelectItem>
                        <SelectItem value="app">Application</SelectItem>
                        <SelectItem value="ecommerce">E-commerce</SelectItem>
                        <SelectItem value="communication">Communication</SelectItem>
                        <SelectItem value="multiple">Projet global</SelectItem>
                        <SelectItem value="other">Autre</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="budget" className="text-[#111111] mb-3 block">Budget estimé</Label>
                      <Select>
                        <SelectTrigger className="glass-subtle text-[#111111] rounded-lg h-14">
                          <SelectValue placeholder="Sélectionnez..." />
                        </SelectTrigger>
                        <SelectContent className="glass-strong border-[#E6E6E6] text-[#111111]">
                          <SelectItem value="5-10">5k - 10k€</SelectItem>
                          <SelectItem value="10-25">10k - 25k€</SelectItem>
                          <SelectItem value="25-50">25k - 50k€</SelectItem>
                          <SelectItem value="50+">50k€ +</SelectItem>
                          <SelectItem value="tbd">À définir</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="timeline" className="text-[#111111] mb-3 block">Délai souhaité</Label>
                      <Select>
                        <SelectTrigger className="glass-subtle text-[#111111] rounded-lg h-14">
                          <SelectValue placeholder="Sélectionnez..." />
                        </SelectTrigger>
                        <SelectContent className="glass-strong border-[#E6E6E6] text-[#111111]">
                          <SelectItem value="urgent">Urgent ({"<"} 1 mois)</SelectItem>
                          <SelectItem value="1-3">1-3 mois</SelectItem>
                          <SelectItem value="3-6">3-6 mois</SelectItem>
                          <SelectItem value="6+">6 mois +</SelectItem>
                          <SelectItem value="flexible">Flexible</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="message" className="text-[#111111] mb-3 block">Message</Label>
                    <Textarea
                      id="message"
                      placeholder="Parlez-nous de votre projet, vos objectifs, vos contraintes..."
                      rows={7}
                      className="glass-subtle text-[#111111] placeholder:text-[#999999] rounded-lg focus:border-[#E01919] resize-none"
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full bg-[#111111] hover:bg-[#E01919] text-white h-14 rounded-lg transition-all duration-300"
                  >
                    Envoyer le message
                  </Button>
                </form>
              </div>

              {/* Contact Info */}
              <div className="space-y-6">
                <div className="p-10 glass rounded-xl">
                  <h3 className="text-[#111111] font-['Space_Grotesk'] mb-8 font-normal">Contact direct</h3>
                  <div className="space-y-6">
                    <div>
                      <div className="text-[#999999] text-[11px] mono mb-3 tracking-[0.15em]">EMAIL</div>
                      <a href="mailto:hello@skwr-studio.com" className="text-[#111111] hover:text-[#E01919] transition-colors">
                        hello@skwr-studio.com
                      </a>
                    </div>
                    <div>
                      <div className="text-[#999999] text-[11px] mono mb-3 tracking-[0.15em]">TÉLÉPHONE</div>
                      <a href="tel:+33123456789" className="text-[#111111] hover:text-[#E01919] transition-colors">
                        +33 1 23 45 67 89
                      </a>
                    </div>
                    <div>
                      <div className="text-[#999999] text-[11px] mono mb-3 tracking-[0.15em]">ADRESSE</div>
                      <p className="text-[#666666] text-[15px] leading-relaxed">
                        75 Avenue Parmentier<br />
                        75011 Paris, France
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-10 glass rounded-xl">
                  <h3 className="text-[#111111] font-['Space_Grotesk'] mb-6 font-normal">Horaires</h3>
                  <div className="space-y-4 text-[15px]">
                    <div className="flex justify-between items-center">
                      <span className="text-[#666666]">Lun - Ven</span>
                      <span className="text-[#111111]">9h - 18h</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-[#666666]">Weekend</span>
                      <span className="text-[#999999]">Fermé</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-32">
            <Footer />
          </div>
        </div>
      )}
    </div>
  );
}
