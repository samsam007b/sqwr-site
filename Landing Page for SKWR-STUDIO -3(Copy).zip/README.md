
  # Landing Page for SKWR-STUDIO (Copy)

  This is a code bundle for Landing Page for SKWR-STUDIO (Copy). The original project is available at https://www.figma.com/design/2cJ5YpGS5YLyTALcn8GG8L/Landing-Page-for-SKWR-STUDIO--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  