import React from 'react';

interface TagProps {
  children: React.ReactNode;
  variant?: 'default' | 'accent';
  className?: string;
}

export function Tag({ children, variant = 'default', className = '' }: TagProps) {
  const baseStyles = 'inline-flex items-center px-3 py-1 text-xs font-mono uppercase tracking-wider border transition-colors';
  
  const variants = {
    default: 'border-gray-medium bg-gray-dark text-white hover:border-white',
    accent: 'border-red-accent text-red-accent hover:bg-red-accent hover:text-white'
  };
  
  return (
    <span className={`${baseStyles} ${variants[variant]} ${className}`} style={{ borderRadius: '4px' }}>
      {children}
    </span>
  );
}
