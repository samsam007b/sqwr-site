import React from 'react';

interface Step {
  number: string;
  title: string;
  description: string;
}

interface StepperProps {
  steps: Step[];
}

export function Stepper({ steps }: StepperProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
      {steps.map((step, index) => (
        <div key={index} className="relative">
          <div className="mb-4">
            <div 
              className="inline-flex items-center justify-center w-16 h-16 border-2 border-red-accent text-red-accent"
              style={{ borderRadius: '4px', fontFamily: 'var(--font-mono)' }}
            >
              {step.number}
            </div>
          </div>
          <h4 className="mb-3 text-white" style={{ fontFamily: 'var(--font-heading)' }}>
            {step.title}
          </h4>
          <p className="text-muted-foreground leading-relaxed">
            {step.description}
          </p>
          {index < steps.length - 1 && (
            <div className="hidden md:block absolute top-8 left-full w-full h-px bg-gray-medium" 
                 style={{ transform: 'translateX(-50%)' }} />
          )}
        </div>
      ))}
    </div>
  );
}
