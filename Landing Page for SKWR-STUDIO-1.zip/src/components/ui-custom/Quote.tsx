import React from 'react';
import { Quote as QuoteIcon } from 'lucide-react';

interface QuoteProps {
  text: string;
  author: string;
  role?: string;
  company?: string;
}

export function Quote({ text, author, role, company }: QuoteProps) {
  return (
    <div className="relative p-8 border border-gray-medium bg-gray-dark" style={{ borderRadius: '8px' }}>
      <QuoteIcon className="w-8 h-8 text-red-accent mb-4" />
      <blockquote className="text-xl text-white mb-6 leading-relaxed">
        "{text}"
      </blockquote>
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-full bg-gray-medium" />
        <div>
          <div className="text-white" style={{ fontFamily: 'var(--font-heading)' }}>{author}</div>
          {(role || company) && (
            <div className="text-sm text-muted-foreground">
              {role}{role && company && ', '}{company}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
