import React, { useState, useEffect } from 'react';
import { Square } from 'lucide-react';

interface AppBarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export function AppBar({ currentPage, onNavigate }: AppBarProps) {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'home', label: 'Accueil' },
    { id: 'cases', label: 'Cases' },
    { id: 'services', label: 'Services' },
    { id: 'contact', label: 'Contact' }
  ];

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-onyx/95 backdrop-blur-sm border-b border-gray-medium' : 'bg-transparent'}`}
    >
      <div className="container-custom">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-2 group"
          >
            <div className="w-10 h-10 bg-red-accent flex items-center justify-center transition-transform duration-300 group-hover:rotate-90"
                 style={{ borderRadius: '4px' }}>
              <Square className="w-6 h-6 text-white" fill="white" />
            </div>
            <span 
              className="text-xl text-white tracking-tight"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              SKWR-STUDIO
            </span>
          </button>

          {/* Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`relative text-sm transition-colors ${currentPage === item.id ? 'text-white' : 'text-muted-foreground hover:text-white'}`}
                style={{ fontFamily: 'var(--font-body)' }}
              >
                {item.label}
                {currentPage === item.id && (
                  <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-red-accent" />
                )}
              </button>
            ))}
          </nav>

          {/* CTA Button */}
          <button
            onClick={() => onNavigate('contact')}
            className="hidden lg:flex items-center gap-2 px-6 py-3 bg-red-accent text-white transition-all duration-300 hover:bg-white hover:text-onyx"
            style={{ borderRadius: '4px', fontFamily: 'var(--font-body)' }}
          >
            Démarrer un projet
          </button>

          {/* Mobile menu button */}
          <button 
            className="md:hidden w-10 h-10 flex flex-col items-center justify-center gap-1.5"
            onClick={() => {/* TODO: Mobile menu */}}
          >
            <span className="w-6 h-0.5 bg-white" />
            <span className="w-6 h-0.5 bg-white" />
            <span className="w-6 h-0.5 bg-white" />
          </button>
        </div>
      </div>
    </header>
  );
}
