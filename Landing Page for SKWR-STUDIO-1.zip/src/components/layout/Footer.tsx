import React from 'react';
import { Square, Mail, Linkedin, Instagram, Github } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: string) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  const currentYear = new Date().getFullYear();

  const links = {
    pages: [
      { label: 'Accueil', id: 'home' },
      { label: 'Cases', id: 'cases' },
      { label: 'Services', id: 'services' },
      { label: 'Contact', id: 'contact' }
    ],
    services: [
      'Graphisme',
      'Code',
      'Communication'
    ],
    social: [
      { icon: Linkedin, href: '#', label: 'LinkedIn' },
      { icon: Instagram, href: '#', label: 'Instagram' },
      { icon: Github, href: '#', label: 'Github' }
    ]
  };

  return (
    <footer className="border-t border-gray-medium bg-onyx">
      <div className="container-custom py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 bg-red-accent flex items-center justify-center"
                   style={{ borderRadius: '4px' }}>
                <Square className="w-6 h-6 text-white" fill="white" />
              </div>
              <span 
                className="text-xl text-white tracking-tight"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                SKWR-STUDIO
              </span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Agence familiale premium. Graphisme, Code & Communication.
            </p>
          </div>

          {/* Pages */}
          <div>
            <h4 
              className="text-sm text-white mb-4"
              style={{ fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '0.05em' }}
            >
              Navigation
            </h4>
            <ul className="space-y-2">
              {links.pages.map((link) => (
                <li key={link.id}>
                  <button
                    onClick={() => onNavigate(link.id)}
                    className="text-sm text-muted-foreground hover:text-white transition-colors"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 
              className="text-sm text-white mb-4"
              style={{ fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '0.05em' }}
            >
              Pôles
            </h4>
            <ul className="space-y-2">
              {links.services.map((service) => (
                <li key={service}>
                  <span className="text-sm text-muted-foreground">
                    {service}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 
              className="text-sm text-white mb-4"
              style={{ fontFamily: 'var(--font-mono)', textTransform: 'uppercase', letterSpacing: '0.05em' }}
            >
              Contact
            </h4>
            <div className="space-y-3 mb-4">
              <a 
                href="mailto:hello@skwr-studio.com" 
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-white transition-colors"
              >
                <Mail className="w-4 h-4" />
                hello@skwr-studio.com
              </a>
            </div>
            
            {/* Social */}
            <div className="flex gap-3">
              {links.social.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  className="w-10 h-10 flex items-center justify-center border border-gray-medium hover:border-red-accent hover:bg-red-accent transition-all duration-300 group"
                  style={{ borderRadius: '4px' }}
                  aria-label={social.label}
                >
                  <social.icon className="w-5 h-5 text-muted-foreground group-hover:text-white transition-colors" />
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-gray-medium flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            © {currentYear} SKWR-STUDIO. Tous droits réservés.
          </p>
          <div className="flex gap-6 text-sm text-muted-foreground">
            <button className="hover:text-white transition-colors">
              Mentions légales
            </button>
            <button className="hover:text-white transition-colors">
              Politique de confidentialité
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
