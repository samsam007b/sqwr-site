import React from 'react';

interface KPI {
  label: string;
  value: string;
}

interface KPIBlockProps {
  kpis: KPI[];
  className?: string;
}

export function KPIBlock({ kpis, className = '' }: KPIBlockProps) {
  if (kpis.length === 0) return null;
  
  return (
    <div className={`grid grid-cols-2 gap-6 ${className}`}>
      {kpis.map((kpi, index) => (
        <div key={index} className="p-6 border border-gray-medium bg-gray-dark" style={{ borderRadius: '4px' }}>
          <div 
            className="text-5xl mb-2 text-red-accent"
            style={{ fontFamily: 'var(--font-heading)' }}
          >
            {kpi.value}
          </div>
          <div className="text-sm text-muted-foreground uppercase tracking-wider" style={{ fontFamily: 'var(--font-mono)' }}>
            {kpi.label}
          </div>
        </div>
      ))}
    </div>
  );
}
