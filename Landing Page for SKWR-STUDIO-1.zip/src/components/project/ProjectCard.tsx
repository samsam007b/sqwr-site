import React, { useState } from 'react';
import { Tag } from '../ui-custom/Tag';
import { ImageWithFallback } from '../figma/ImageWithFallback';
import { ArrowUpRight } from 'lucide-react';
import type { Project } from '../../data/projects';

interface ProjectCardProps {
  project: Project;
  onClick?: () => void;
  size?: 'small' | 'medium' | 'large';
}

const projectImages: Record<string, string> = {
  'squarebrew': 'https://images.unsplash.com/photo-1634578194401-dd15f628f328?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2ZmZWUlMjBzaG9wJTIwYnJhbmRpbmd8ZW58MXx8fHwxNzYxOTI4ODE4fDA&ixlib=rb-4.1.0&q=80&w=1080',
  'monolithe': 'https://images.unsplash.com/photo-1681216868987-b7268753b81c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhcmNoaXRlY3R1cmUlMjBtb2Rlcm4lMjBidWlsZGluZ3xlbnwxfHx8fDE3NjE5MjA5ODl8MA&ixlib=rb-4.1.0&q=80&w=1080',
  'flare': 'https://images.unsplash.com/photo-1658274474930-bb27a64022c2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsYXB0b3AlMjBjb2RlJTIwc2NyZWVufGVufDF8fHx8MTc2MTkyOTQ1NXww&ixlib=rb-4.1.0&q=80&w=1080',
  'novarun': 'https://images.unsplash.com/photo-1658953229625-aad99d7603b4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2JpbGUlMjBhcHAlMjBpbnRlcmZhY2V8ZW58MXx8fHwxNzYxODgwMjM1fDA&ixlib=rb-4.1.0&q=80&w=1080',
  'musea': 'https://images.unsplash.com/photo-1706665714936-3211c96474c8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtdXNldW0lMjBleGhpYml0aW9uJTIwYXJ0fGVufDF8fHx8MTc2MTg1NDk3Nnww&ixlib=rb-4.1.0&q=80&w=1080',
  'parallele': 'https://images.unsplash.com/photo-1614036634955-ae5e90f9b9eb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWdhemluZSUyMGVkaXRvcmlhbCUyMGRlc2lnbnxlbnwxfHx8fDE3NjE5MzQ0MTN8MA&ixlib=rb-4.1.0&q=80&w=1080',
};

export function ProjectCard({ project, onClick, size = 'medium' }: ProjectCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  
  const sizeClasses = {
    small: 'h-64',
    medium: 'h-96',
    large: 'h-[32rem]'
  };

  const imageUrl = projectImages[project.id] || 'https://images.unsplash.com/photo-1658274474930-bb27a64022c2?w=1080';

  return (
    <div
      className={`group relative overflow-hidden cursor-pointer border border-gray-medium bg-gray-dark transition-all duration-300 ${sizeClasses[size]} ${isHovered ? 'border-red-accent' : ''}`}
      style={{ borderRadius: '4px' }}
      onClick={onClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Image */}
      <div className="relative w-full h-2/3 overflow-hidden">
        <ImageWithFallback
          src={imageUrl}
          alt={project.title}
          className={`w-full h-full object-cover transition-transform duration-500 ${isHovered ? 'scale-110 animate-glitch' : ''}`}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-gray-dark via-transparent to-transparent opacity-80" />
        
        {/* Hover overlay */}
        <div className={`absolute inset-0 bg-red-accent transition-opacity duration-300 ${isHovered ? 'opacity-10' : 'opacity-0'}`} />
      </div>

      {/* Content */}
      <div className="relative p-6 h-1/3 flex flex-col justify-between">
        <div>
          <div className="flex flex-wrap gap-2 mb-3">
            {project.poles.map((pole, index) => (
              <Tag key={index} variant="default">
                {pole}
              </Tag>
            ))}
          </div>
          
          <h3 
            className="text-2xl text-white mb-1 transition-colors"
            style={{ fontFamily: 'var(--font-heading)' }}
          >
            {project.title}
          </h3>
          
          <p className="text-sm text-muted-foreground mb-2">
            {project.client}
          </p>
        </div>

        {project.kpis.length > 0 && (
          <div className="flex gap-4 text-sm">
            {project.kpis.slice(0, 2).map((kpi, index) => (
              <div key={index}>
                <span className="text-red-accent" style={{ fontFamily: 'var(--font-mono)' }}>
                  {kpi.value}
                </span>
                <span className="text-muted-foreground ml-1">
                  {kpi.label}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Arrow indicator */}
      <div className={`absolute top-4 right-4 w-10 h-10 flex items-center justify-center bg-red-accent transition-all duration-300 ${isHovered ? 'scale-110' : 'scale-0'}`}
           style={{ borderRadius: '4px' }}>
        <ArrowUpRight className="w-5 h-5 text-white" />
      </div>
    </div>
  );
}
