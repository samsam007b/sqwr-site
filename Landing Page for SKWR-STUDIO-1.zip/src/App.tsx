import React, { useState, useEffect } from 'react';
import { AppBar } from './components/layout/AppBar';
import { Footer } from './components/layout/Footer';
import { Home } from './pages/Home';
import { Cases } from './pages/Cases';
import { CaseDetail } from './pages/CaseDetail';
import { Services } from './pages/Services';
import { Contact } from './pages/Contact';
import './styles/globals.css';

type Page = 'home' | 'cases' | 'case-detail' | 'services' | 'contact';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(null);

  const handleNavigate = (page: string, projectId?: string) => {
    setCurrentPage(page as Page);
    if (projectId) {
      setSelectedProjectId(projectId);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    // Scroll to top on mount
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen bg-onyx text-white">
      <AppBar currentPage={currentPage} onNavigate={handleNavigate} />
      
      <main>
        {currentPage === 'home' && <Home onNavigate={handleNavigate} />}
        {currentPage === 'cases' && <Cases onNavigate={handleNavigate} />}
        {currentPage === 'case-detail' && selectedProjectId && (
          <CaseDetail projectId={selectedProjectId} onNavigate={handleNavigate} />
        )}
        {currentPage === 'services' && <Services onNavigate={handleNavigate} />}
        {currentPage === 'contact' && <Contact onNavigate={handleNavigate} />}
      </main>
      
      <Footer onNavigate={handleNavigate} />
    </div>
  );
}

export default App;
