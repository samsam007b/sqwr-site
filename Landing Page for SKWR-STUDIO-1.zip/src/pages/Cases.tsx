import React, { useState } from 'react';
import { ProjectCard } from '../components/project/ProjectCard';
import { Tag } from '../components/ui-custom/Tag';
import { projects } from '../data/projects';
import { Filter } from 'lucide-react';

interface CasesProps {
  onNavigate: (page: string, projectId?: string) => void;
}

export function Cases({ onNavigate }: CasesProps) {
  const [selectedPole, setSelectedPole] = useState<string | null>(null);

  const poles = ['Graphisme', 'Code', 'Communication'];

  const filteredProjects = selectedPole
    ? projects.filter(p => p.poles.includes(selectedPole as any))
    : projects;

  return (
    <div className="min-h-screen pt-20">
      {/* Header */}
      <section className="py-16 border-b border-gray-medium">
        <div className="container-custom">
          <div className="max-w-4xl">
            <h1 
              className="text-7xl mb-6 text-white"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              Nos Cases
            </h1>
            <p className="text-2xl text-muted-foreground leading-relaxed">
              Découvrez comment nous transformons les défis de nos clients en succès mesurables, projet après projet.
            </p>
          </div>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 border-b border-gray-medium sticky top-20 bg-onyx/95 backdrop-blur-sm z-40">
        <div className="container-custom">
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Filter className="w-4 h-4" />
              <span style={{ fontFamily: 'var(--font-mono)', textTransform: 'uppercase' }}>
                Filtrer par pôle
              </span>
            </div>
            
            <button
              onClick={() => setSelectedPole(null)}
              className={`px-4 py-2 border transition-all ${!selectedPole ? 'border-red-accent bg-red-accent text-white' : 'border-gray-medium text-muted-foreground hover:border-white hover:text-white'}`}
              style={{ borderRadius: '4px' }}
            >
              Tous
            </button>
            
            {poles.map((pole) => (
              <button
                key={pole}
                onClick={() => setSelectedPole(pole)}
                className={`px-4 py-2 border transition-all ${selectedPole === pole ? 'border-red-accent bg-red-accent text-white' : 'border-gray-medium text-muted-foreground hover:border-white hover:text-white'}`}
                style={{ borderRadius: '4px' }}
              >
                {pole}
              </button>
            ))}
            
            <div className="ml-auto text-sm text-muted-foreground" style={{ fontFamily: 'var(--font-mono)' }}>
              {filteredProjects.length} projet{filteredProjects.length > 1 ? 's' : ''}
            </div>
          </div>
        </div>
      </section>

      {/* Projects Grid */}
      <section className="py-16">
        <div className="container-custom">
          {filteredProjects.length === 0 ? (
            <div className="text-center py-20">
              <p className="text-xl text-muted-foreground">
                Aucun projet trouvé pour ce filtre
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredProjects.map((project) => (
                <ProjectCard
                  key={project.id}
                  project={project}
                  onClick={() => onNavigate('case-detail', project.id)}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 border-t border-gray-medium">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center">
            <h2 
              className="text-5xl mb-6 text-white"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              Prêt à créer votre propre case ?
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              Parlons de votre projet et voyons comment nous pouvons vous aider à atteindre vos objectifs.
            </p>
            <button
              onClick={() => onNavigate('contact')}
              className="px-8 py-4 bg-red-accent text-white transition-all duration-300 hover:bg-white hover:text-onyx"
              style={{ borderRadius: '4px' }}
            >
              Démarrer un projet
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
