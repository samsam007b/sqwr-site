import React from 'react';
import { ArrowRight, Palette, Code2, Megaphone } from 'lucide-react';
import { ProjectCard } from '../components/project/ProjectCard';
import { Quote } from '../components/ui-custom/Quote';
import { Stepper } from '../components/ui-custom/Stepper';
import { Tag } from '../components/ui-custom/Tag';
import { featuredProjects } from '../data/projects';

interface HomeProps {
  onNavigate: (page: string, projectId?: string) => void;
}

export function Home({ onNavigate }: HomeProps) {
  const poles = [
    {
      icon: Palette,
      title: 'Graphisme',
      description: 'Identités visuelles, packaging, direction artistique et édition.'
    },
    {
      icon: Code2,
      title: 'Code',
      description: 'Sites web, applications, design systèmes et expériences digitales.'
    },
    {
      icon: Megaphone,
      title: 'Communication',
      description: 'Stratégies social media, campagnes et contenus engageants.'
    }
  ];

  const process = [
    {
      number: '01',
      title: 'Découverte',
      description: 'Nous plongeons dans votre univers, vos ambitions et vos défis pour comprendre l\'essence de votre projet.'
    },
    {
      number: '02',
      title: 'Conception',
      description: 'Notre équipe crée des solutions sur-mesure, alliant créativité et rigueur technique pour donner vie à votre vision.'
    },
    {
      number: '03',
      title: 'Déploiement',
      description: 'Nous accompagnons le lancement et veillons à ce que chaque détail soit parfait, du premier pixel au dernier utilisateur.'
    }
  ];

  const stats = [
    { value: '50+', label: 'Projets livrés' },
    { value: '12', label: 'Années d\'expérience' },
    { value: '100%', label: 'Satisfaction client' },
    { value: '3', label: 'Pôles d\'expertise' }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center pt-20">
        <div className="container-custom py-20">
          <div className="max-w-5xl mx-auto text-center">
            <div className="mb-6 inline-block">
              <Tag variant="accent">Agence familiale premium</Tag>
            </div>
            
            <h1 
              className="mb-8 text-white animate-wipe"
              style={{ 
                fontFamily: 'var(--font-heading)', 
                fontSize: 'clamp(3rem, 8vw, 6.5rem)',
                lineHeight: '1.1',
                letterSpacing: '-0.02em'
              }}
            >
              Design carré,
              <br />
              <span className="text-red-accent">ambitions sans limites</span>
            </h1>
            
            <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed">
              SKWR-STUDIO allie graphisme, code et communication pour transformer vos idées en expériences mémorables et performantes.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => onNavigate('contact')}
                className="px-8 py-4 bg-red-accent text-white transition-all duration-300 hover:bg-white hover:text-onyx flex items-center justify-center gap-2 group"
                style={{ borderRadius: '4px', fontFamily: 'var(--font-body)' }}
              >
                Démarrer un projet
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              
              <button
                onClick={() => onNavigate('cases')}
                className="px-8 py-4 border-2 border-white text-white transition-all duration-300 hover:bg-white hover:text-onyx"
                style={{ borderRadius: '4px', fontFamily: 'var(--font-body)' }}
              >
                Voir nos cases
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Poles Section */}
      <section className="py-24 border-t border-gray-medium">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {poles.map((pole, index) => (
              <div 
                key={index}
                className="p-8 border border-gray-medium bg-gray-dark hover:border-red-accent transition-all duration-300 group"
                style={{ borderRadius: '8px' }}
              >
                <div className="w-16 h-16 mb-6 bg-red-accent/10 flex items-center justify-center group-hover:bg-red-accent transition-colors"
                     style={{ borderRadius: '4px' }}>
                  <pole.icon className="w-8 h-8 text-red-accent group-hover:text-white transition-colors" />
                </div>
                
                <h3 
                  className="text-2xl mb-3 text-white"
                  style={{ fontFamily: 'var(--font-heading)' }}
                >
                  {pole.title}
                </h3>
                
                <p className="text-muted-foreground leading-relaxed">
                  {pole.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Projects */}
      <section className="py-24 border-t border-gray-medium">
        <div className="container-custom">
          <div className="flex items-end justify-between mb-12">
            <div>
              <h2 
                className="text-5xl mb-4 text-white"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                Cases récents
              </h2>
              <p className="text-xl text-muted-foreground">
                Découvrez nos projets les plus emblématiques
              </p>
            </div>
            
            <button
              onClick={() => onNavigate('cases')}
              className="hidden md:flex items-center gap-2 text-red-accent hover:gap-4 transition-all"
            >
              Voir tous les projets
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredProjects.map((project) => (
              <ProjectCard
                key={project.id}
                project={project}
                onClick={() => onNavigate('case-detail', project.id)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-24 border-t border-gray-medium">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto mb-16 text-center">
            <h2 
              className="text-5xl mb-6 text-white"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              Notre processus
            </h2>
            <p className="text-xl text-muted-foreground">
              Une méthode éprouvée en trois phases pour transformer vos ambitions en réalité
            </p>
          </div>
          
          <Stepper steps={process} />
        </div>
      </section>

      {/* Stats & Proof */}
      <section className="py-24 border-t border-gray-medium bg-gray-dark/30">
        <div className="container-custom">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div 
                  className="text-6xl mb-2 text-red-accent"
                  style={{ fontFamily: 'var(--font-heading)' }}
                >
                  {stat.value}
                </div>
                <div 
                  className="text-sm text-muted-foreground uppercase tracking-wider"
                  style={{ fontFamily: 'var(--font-mono)' }}
                >
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
          
          <div className="max-w-3xl mx-auto">
            <Quote
              text="SKWR-STUDIO a transformé notre vision en une identité visuelle puissante qui résonne parfaitement avec notre audience. Leur approche méthodique et leur créativité sans compromis ont dépassé toutes nos attentes."
              author="Marie Dubois"
              role="CEO"
              company="TechFlow"
            />
          </div>
        </div>
      </section>

      {/* Studio Section */}
      <section className="py-24 border-t border-gray-medium">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 
                className="text-5xl mb-6 text-white"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                Une agence familiale qui pense grand
              </h2>
              
              <p className="text-xl text-muted-foreground mb-8 leading-relaxed">
                Fondé en 2012, SKWR-STUDIO est né de la passion commune d'une famille pour le design, la technologie et la communication. Notre approche unique combine l'agilité d'une petite équipe avec l'exigence d'une grande agence.
              </p>
              
              <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                Chaque projet est une collaboration étroite où nous mettons notre expertise au service de votre vision. Nous croyons que les meilleures créations naissent de la rencontre entre ambition et rigueur.
              </p>
              
              <button
                onClick={() => onNavigate('contact')}
                className="px-8 py-4 bg-red-accent text-white transition-all duration-300 hover:bg-white hover:text-onyx flex items-center gap-2 group"
                style={{ borderRadius: '4px' }}
              >
                Parlons de votre projet
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </div>
            
            <div className="relative">
              <div className="aspect-square bg-gray-dark border border-gray-medium"
                   style={{ borderRadius: '8px' }}>
                <div className="w-full h-full flex items-center justify-center">
                  <div className="text-center text-muted-foreground">
                    <div className="w-24 h-24 mx-auto mb-4 bg-red-accent/10 flex items-center justify-center"
                         style={{ borderRadius: '4px' }}>
                      <Code2 className="w-12 h-12 text-red-accent" />
                    </div>
                    <p className="text-sm" style={{ fontFamily: 'var(--font-mono)' }}>
                      STUDIO_IMAGE
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
