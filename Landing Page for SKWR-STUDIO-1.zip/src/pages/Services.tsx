import React from 'react';
import { Palette, Code2, Megaphone, Check, ArrowRight } from 'lucide-react';

interface ServicesProps {
  onNavigate: (page: string) => void;
}

export function Services({ onNavigate }: ServicesProps) {
  const services = [
    {
      icon: Palette,
      pole: 'Graphisme',
      tagline: 'Créer des identités visuelles mémorables',
      description: 'Nous concevons des identités visuelles fortes et cohérentes qui capturent l\'essence de votre marque et résonnent avec votre audience.',
      offerings: [
        'Identité de marque & logo',
        'Charte graphique complète',
        'Packaging & design produit',
        'Direction artistique',
        'Design éditorial',
        'Signalétique & wayfinding',
        'Illustrations sur-mesure',
        'Photographie & retouches'
      ]
    },
    {
      icon: Code2,
      pole: 'Code',
      tagline: 'Développer des expériences digitales performantes',
      description: 'Nos développeurs créent des sites web et applications qui allient esthétique, performance et expérience utilisateur optimale.',
      offerings: [
        'Sites web sur-mesure',
        'Applications web (SaaS)',
        'Applications mobiles',
        'E-commerce (Shopify, WooCommerce)',
        'Design systèmes & UI kits',
        'Prototypes interactifs',
        'Optimisation performance',
        'Maintenance & support'
      ]
    },
    {
      icon: Megaphone,
      pole: 'Communication',
      tagline: 'Amplifier votre présence et votre impact',
      description: 'Nous élaborons des stratégies de communication efficaces qui engagent votre audience et génèrent des résultats mesurables.',
      offerings: [
        'Stratégie de contenu',
        'Social media management',
        'Campagnes publicitaires',
        'Content creation (photo/vidéo)',
        'Motion design & animation',
        'Copywriting & storytelling',
        'Email marketing',
        'Analytics & reporting'
      ]
    }
  ];

  const packs = [
    {
      name: 'Starter',
      price: 'Sur devis',
      description: 'Idéal pour les startups et petites entreprises qui démarrent leur aventure.',
      features: [
        'Identité visuelle de base',
        'Site vitrine (5 pages)',
        'Pack social media',
        '1 mois de support',
        'Formation aux outils'
      ],
      popular: false
    },
    {
      name: 'Growth',
      price: 'Sur devis',
      description: 'Pour les entreprises en croissance qui veulent passer au niveau supérieur.',
      features: [
        'Identité complète + guidelines',
        'Site web custom ou application',
        'Stratégie de communication',
        '3 mois de support',
        'Analytics & optimisation',
        'Design système complet'
      ],
      popular: true
    },
    {
      name: 'Premium',
      price: 'Sur devis',
      description: 'Solution complète pour les entreprises ambitieuses qui ne font pas de compromis.',
      features: [
        'Tout du pack Growth',
        'Campagnes multi-canal',
        'Direction artistique complète',
        'Support prioritaire illimité',
        'A/B testing & optimisation',
        'Formation équipe interne',
        'Collaboration long terme'
      ],
      popular: false
    }
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Header */}
      <section className="py-16 border-b border-gray-medium">
        <div className="container-custom">
          <div className="max-w-4xl">
            <h1 
              className="text-7xl mb-6 text-white"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              Nos Services
            </h1>
            <p className="text-2xl text-muted-foreground leading-relaxed">
              Trois pôles d'expertise pour répondre à tous vos besoins créatifs, techniques et stratégiques.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-24">
        <div className="container-custom">
          <div className="grid grid-cols-1 gap-16">
            {services.map((service, index) => (
              <div 
                key={index}
                className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start"
              >
                {/* Left: Icon & Description */}
                <div>
                  <div className="w-20 h-20 mb-6 bg-red-accent/10 flex items-center justify-center"
                       style={{ borderRadius: '4px' }}>
                    <service.icon className="w-10 h-10 text-red-accent" />
                  </div>
                  
                  <h2 
                    className="text-5xl mb-4 text-white"
                    style={{ fontFamily: 'var(--font-heading)' }}
                  >
                    {service.pole}
                  </h2>
                  
                  <p className="text-xl text-red-accent mb-6" style={{ fontFamily: 'var(--font-heading)' }}>
                    {service.tagline}
                  </p>
                  
                  <p className="text-lg text-muted-foreground leading-relaxed">
                    {service.description}
                  </p>
                </div>

                {/* Right: Offerings */}
                <div className="p-8 border border-gray-medium bg-gray-dark"
                     style={{ borderRadius: '8px' }}>
                  <h3 
                    className="text-xl mb-6 text-white"
                    style={{ fontFamily: 'var(--font-heading)' }}
                  >
                    Ce que nous proposons
                  </h3>
                  
                  <ul className="space-y-4">
                    {service.offerings.map((offering, idx) => (
                      <li key={idx} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-red-accent flex-shrink-0 mt-0.5" />
                        <span className="text-muted-foreground">
                          {offering}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Packs Section */}
      <section className="py-24 border-t border-gray-medium bg-gray-dark/30">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto text-center mb-16">
            <h2 
              className="text-5xl mb-6 text-white"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              Nos Packs
            </h2>
            <p className="text-xl text-muted-foreground">
              Des formules adaptées à chaque ambition et chaque budget
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {packs.map((pack, index) => (
              <div
                key={index}
                className={`relative p-8 border bg-gray-dark transition-all duration-300 hover:border-red-accent ${pack.popular ? 'border-red-accent' : 'border-gray-medium'}`}
                style={{ borderRadius: '8px' }}
              >
                {pack.popular && (
                  <div 
                    className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-red-accent text-white text-xs uppercase tracking-wider"
                    style={{ borderRadius: '4px', fontFamily: 'var(--font-mono)' }}
                  >
                    Populaire
                  </div>
                )}

                <h3 
                  className="text-3xl mb-2 text-white"
                  style={{ fontFamily: 'var(--font-heading)' }}
                >
                  {pack.name}
                </h3>

                <div className="text-4xl mb-4 text-red-accent" style={{ fontFamily: 'var(--font-heading)' }}>
                  {pack.price}
                </div>

                <p className="text-sm text-muted-foreground mb-8 leading-relaxed">
                  {pack.description}
                </p>

                <ul className="space-y-3 mb-8">
                  {pack.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2">
                      <Check className="w-4 h-4 text-red-accent flex-shrink-0 mt-1" />
                      <span className="text-sm text-muted-foreground">
                        {feature}
                      </span>
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => onNavigate('contact')}
                  className={`w-full py-3 transition-all duration-300 ${pack.popular ? 'bg-red-accent text-white hover:bg-white hover:text-onyx' : 'border border-white text-white hover:bg-white hover:text-onyx'}`}
                  style={{ borderRadius: '4px' }}
                >
                  Demander un devis
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-24 border-t border-gray-medium">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto">
            <h2 
              className="text-5xl mb-8 text-white text-center"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              Comment ça marche ?
            </h2>
            
            <div className="space-y-8">
              {[
                {
                  step: '01',
                  title: 'Premier contact',
                  description: 'Prenez rendez-vous pour un premier échange gratuit de 30 minutes. Nous discutons de votre projet, vos besoins et vos objectifs.'
                },
                {
                  step: '02',
                  title: 'Proposition & devis',
                  description: 'Nous vous envoyons une proposition détaillée avec un devis transparent, un planning prévisionnel et nos recommandations.'
                },
                {
                  step: '03',
                  title: 'Collaboration',
                  description: 'Une fois le projet lancé, nous travaillons en étroite collaboration avec vous à travers des points réguliers et des livrables intermédiaires.'
                },
                {
                  step: '04',
                  title: 'Livraison & suivi',
                  description: 'Nous livrons le projet finalisé avec toute la documentation nécessaire et assurons un suivi pour garantir votre satisfaction.'
                }
              ].map((item, index) => (
                <div key={index} className="flex gap-6 p-6 border border-gray-medium hover:border-red-accent transition-all"
                     style={{ borderRadius: '8px' }}>
                  <div 
                    className="text-4xl text-red-accent flex-shrink-0"
                    style={{ fontFamily: 'var(--font-mono)' }}
                  >
                    {item.step}
                  </div>
                  <div>
                    <h3 className="text-2xl mb-2 text-white" style={{ fontFamily: 'var(--font-heading)' }}>
                      {item.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 border-t border-gray-medium">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center">
            <h2 
              className="text-5xl mb-6 text-white"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              Prêt à démarrer ?
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              Discutons de votre projet et trouvons ensemble la meilleure approche pour atteindre vos objectifs.
            </p>
            <button
              onClick={() => onNavigate('contact')}
              className="inline-flex items-center gap-2 px-8 py-4 bg-red-accent text-white transition-all duration-300 hover:bg-white hover:text-onyx group"
              style={{ borderRadius: '4px' }}
            >
              Prendre rendez-vous
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
