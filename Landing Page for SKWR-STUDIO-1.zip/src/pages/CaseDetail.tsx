import React from 'react';
import { ArrowLeft, ExternalLink } from 'lucide-react';
import { Tag } from '../components/ui-custom/Tag';
import { KPIBlock } from '../components/project/KPIBlock';
import { Stepper } from '../components/ui-custom/Stepper';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { projects } from '../data/projects';

interface CaseDetailProps {
  projectId: string;
  onNavigate: (page: string, projectId?: string) => void;
}

export function CaseDetail({ projectId, onNavigate }: CaseDetailProps) {
  const project = projects.find(p => p.id === projectId);

  if (!project) {
    return (
      <div className="min-h-screen pt-20 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl mb-4 text-white" style={{ fontFamily: 'var(--font-heading)' }}>
            Projet non trouvé
          </h1>
          <button
            onClick={() => onNavigate('cases')}
            className="px-6 py-3 bg-red-accent text-white"
            style={{ borderRadius: '4px' }}
          >
            Retour aux cases
          </button>
        </div>
      </div>
    );
  }

  const projectImages: Record<string, string> = {
    'squarebrew': 'https://images.unsplash.com/photo-1634578194401-dd15f628f328?w=1080',
    'monolithe': 'https://images.unsplash.com/photo-1681216868987-b7268753b81c?w=1080',
    'flare': 'https://images.unsplash.com/photo-1658274474930-bb27a64022c2?w=1080',
    'novarun': 'https://images.unsplash.com/photo-1658953229625-aad99d7603b4?w=1080',
    'musea': 'https://images.unsplash.com/photo-1706665714936-3211c96474c8?w=1080',
    'parallele': 'https://images.unsplash.com/photo-1614036634955-ae5e90f9b9eb?w=1080',
  };

  const approachSteps = project.approach?.map((step, index) => ({
    number: `0${index + 1}`,
    title: `Étape ${index + 1}`,
    description: step
  })) || [];

  return (
    <div className="min-h-screen pt-20 animate-wipe">
      {/* Back Button */}
      <div className="container-custom py-8">
        <button
          onClick={() => onNavigate('cases')}
          className="flex items-center gap-2 text-muted-foreground hover:text-white transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Retour aux cases
        </button>
      </div>

      {/* Hero Section */}
      <section className="relative h-[60vh] min-h-[500px] overflow-hidden border-y border-gray-medium">
        <ImageWithFallback
          src={projectImages[project.id] || 'https://images.unsplash.com/photo-1658274474930-bb27a64022c2?w=1080'}
          alt={project.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-onyx via-onyx/50 to-transparent" />
        
        <div className="absolute bottom-0 left-0 right-0">
          <div className="container-custom pb-12">
            <div className="flex flex-wrap gap-2 mb-4">
              {project.poles.map((pole, index) => (
                <Tag key={index} variant="accent">
                  {pole}
                </Tag>
              ))}
            </div>
            
            <h1 
              className="text-7xl mb-4 text-white"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              {project.title}
            </h1>
            
            <p className="text-2xl text-white/80">
              {project.description}
            </p>
          </div>
        </div>
      </section>

      {/* Project Info */}
      <section className="py-16 border-b border-gray-medium">
        <div className="container-custom">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div 
                className="text-xs text-muted-foreground mb-2 uppercase tracking-wider"
                style={{ fontFamily: 'var(--font-mono)' }}
              >
                Client
              </div>
              <div className="text-xl text-white">
                {project.client}
              </div>
            </div>
            
            <div>
              <div 
                className="text-xs text-muted-foreground mb-2 uppercase tracking-wider"
                style={{ fontFamily: 'var(--font-mono)' }}
              >
                Industrie
              </div>
              <div className="text-xl text-white">
                {project.industry}
              </div>
            </div>
            
            <div>
              <div 
                className="text-xs text-muted-foreground mb-2 uppercase tracking-wider"
                style={{ fontFamily: 'var(--font-mono)' }}
              >
                Pôles
              </div>
              <div className="text-xl text-white">
                {project.poles.join(', ')}
              </div>
            </div>
            
            <div>
              <div 
                className="text-xs text-muted-foreground mb-2 uppercase tracking-wider"
                style={{ fontFamily: 'var(--font-mono)' }}
              >
                Livrables
              </div>
              <div className="text-xl text-white">
                {project.deliverables.length}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Context */}
      {project.context && (
        <section className="py-16 border-b border-gray-medium">
          <div className="container-custom">
            <div className="max-w-4xl">
              <h2 
                className="text-4xl mb-6 text-white"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                Contexte
              </h2>
              <p className="text-xl text-muted-foreground leading-relaxed">
                {project.context}
              </p>
            </div>
          </div>
        </section>
      )}

      {/* Challenge */}
      {project.challenge && (
        <section className="py-16 border-b border-gray-medium bg-gray-dark/30">
          <div className="container-custom">
            <div className="max-w-4xl">
              <h2 
                className="text-4xl mb-6 text-white"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                Défi
              </h2>
              <p className="text-xl text-muted-foreground leading-relaxed">
                {project.challenge}
              </p>
            </div>
          </div>
        </section>
      )}

      {/* Approach */}
      {project.approach && project.approach.length > 0 && (
        <section className="py-24 border-b border-gray-medium">
          <div className="container-custom">
            <div className="max-w-4xl mb-16">
              <h2 
                className="text-4xl mb-6 text-white"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                Notre approche
              </h2>
              <p className="text-xl text-muted-foreground leading-relaxed">
                Une méthodologie en trois temps pour répondre aux enjeux du projet.
              </p>
            </div>
            
            <Stepper steps={approachSteps} />
          </div>
        </section>
      )}

      {/* Results & KPIs */}
      {(project.results || project.kpis.length > 0) && (
        <section className="py-16 border-b border-gray-medium">
          <div className="container-custom">
            <div className="max-w-4xl mb-12">
              <h2 
                className="text-4xl mb-6 text-white"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                Résultats
              </h2>
              {project.results && (
                <p className="text-xl text-muted-foreground leading-relaxed mb-8">
                  {project.results}
                </p>
              )}
            </div>
            
            {project.kpis.length > 0 && (
              <KPIBlock kpis={project.kpis} className="max-w-4xl" />
            )}
          </div>
        </section>
      )}

      {/* Stack */}
      {project.stack && project.stack.length > 0 && (
        <section className="py-16 border-b border-gray-medium bg-gray-dark/30">
          <div className="container-custom">
            <div className="max-w-4xl">
              <h2 
                className="text-4xl mb-6 text-white"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                Stack technique
              </h2>
              <div className="flex flex-wrap gap-3">
                {project.stack.map((tech, index) => (
                  <Tag key={index} variant="default">
                    {tech}
                  </Tag>
                ))}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* Deliverables */}
      <section className="py-16 border-b border-gray-medium">
        <div className="container-custom">
          <div className="max-w-4xl">
            <h2 
              className="text-4xl mb-8 text-white"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              Livrables
            </h2>
            <ul className="space-y-3">
              {project.deliverables.map((deliverable, index) => (
                <li key={index} className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-red-accent" style={{ borderRadius: '1px' }} />
                  <span className="text-lg text-muted-foreground">
                    {deliverable}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24">
        <div className="container-custom">
          <div className="max-w-3xl mx-auto text-center">
            <h2 
              className="text-5xl mb-6 text-white"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              Un projet similaire en tête ?
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              Discutons de la manière dont nous pouvons vous aider à atteindre vos objectifs.
            </p>
            <button
              onClick={() => onNavigate('contact')}
              className="px-8 py-4 bg-red-accent text-white transition-all duration-300 hover:bg-white hover:text-onyx"
              style={{ borderRadius: '4px' }}
            >
              Démarrer un projet
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
