import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send } from 'lucide-react';
import { Tag } from '../components/ui-custom/Tag';

interface ContactProps {
  onNavigate: (page: string) => void;
}

export function Contact({ onNavigate }: ContactProps) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    projectType: '',
    budget: '',
    timeline: '',
    message: ''
  });

  const [step, setStep] = useState(1);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    alert('Merci pour votre message ! Nous vous recontacterons dans les 24h.');
  };

  const projectTypes = [
    'Identité de marque',
    'Site web / Application',
    'Campagne communication',
    'Projet complet (multi-pôles)',
    'Autre'
  ];

  const budgetRanges = [
    'Moins de 10k€',
    '10k€ - 25k€',
    '25k€ - 50k€',
    '50k€ - 100k€',
    'Plus de 100k€',
    'À définir'
  ];

  const timelines = [
    'Urgent (< 1 mois)',
    'Court terme (1-3 mois)',
    'Moyen terme (3-6 mois)',
    'Long terme (> 6 mois)',
    'Flexible'
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Header */}
      <section className="py-16 border-b border-gray-medium">
        <div className="container-custom">
          <div className="max-w-4xl">
            <h1 
              className="text-7xl mb-6 text-white"
              style={{ fontFamily: 'var(--font-heading)' }}
            >
              Travaillons ensemble
            </h1>
            <p className="text-2xl text-muted-foreground leading-relaxed">
              Racontez-nous votre projet et découvrons comment nous pouvons vous aider à le concrétiser.
            </p>
          </div>
        </div>
      </section>

      <div className="container-custom py-16">
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-16">
          {/* Contact Info */}
          <div className="lg:col-span-2">
            <div className="lg:sticky lg:top-32">
              <h2 
                className="text-3xl mb-8 text-white"
                style={{ fontFamily: 'var(--font-heading)' }}
              >
                Informations de contact
              </h2>

              <div className="space-y-6 mb-12">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 flex items-center justify-center bg-red-accent/10 flex-shrink-0"
                       style={{ borderRadius: '4px' }}>
                    <Mail className="w-6 h-6 text-red-accent" />
                  </div>
                  <div>
                    <div 
                      className="text-xs text-muted-foreground mb-1 uppercase tracking-wider"
                      style={{ fontFamily: 'var(--font-mono)' }}
                    >
                      Email
                    </div>
                    <a 
                      href="mailto:hello@skwr-studio.com"
                      className="text-lg text-white hover:text-red-accent transition-colors"
                    >
                      hello@skwr-studio.com
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 flex items-center justify-center bg-red-accent/10 flex-shrink-0"
                       style={{ borderRadius: '4px' }}>
                    <Phone className="w-6 h-6 text-red-accent" />
                  </div>
                  <div>
                    <div 
                      className="text-xs text-muted-foreground mb-1 uppercase tracking-wider"
                      style={{ fontFamily: 'var(--font-mono)' }}
                    >
                      Téléphone
                    </div>
                    <a 
                      href="tel:+33123456789"
                      className="text-lg text-white hover:text-red-accent transition-colors"
                    >
                      +33 1 23 45 67 89
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 flex items-center justify-center bg-red-accent/10 flex-shrink-0"
                       style={{ borderRadius: '4px' }}>
                    <MapPin className="w-6 h-6 text-red-accent" />
                  </div>
                  <div>
                    <div 
                      className="text-xs text-muted-foreground mb-1 uppercase tracking-wider"
                      style={{ fontFamily: 'var(--font-mono)' }}
                    >
                      Adresse
                    </div>
                    <div className="text-lg text-white">
                      Paris, France
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-6 border border-gray-medium bg-gray-dark"
                   style={{ borderRadius: '8px' }}>
                <h3 
                  className="text-xl mb-4 text-white"
                  style={{ fontFamily: 'var(--font-heading)' }}
                >
                  Temps de réponse
                </h3>
                <p className="text-muted-foreground leading-relaxed mb-4">
                  Nous répondons généralement sous 24h ouvrées. Pour les demandes urgentes, n'hésitez pas à nous appeler directement.
                </p>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  <span className="text-sm text-muted-foreground" style={{ fontFamily: 'var(--font-mono)' }}>
                    Disponible maintenant
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-3">
            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Step 1: Basic Info */}
              <div className="p-8 border border-gray-medium bg-gray-dark"
                   style={{ borderRadius: '8px' }}>
                <div className="flex items-center justify-between mb-6">
                  <h3 
                    className="text-2xl text-white"
                    style={{ fontFamily: 'var(--font-heading)' }}
                  >
                    Vos informations
                  </h3>
                  <Tag variant="accent">Étape 1/3</Tag>
                </div>

                <div className="space-y-6">
                  <div>
                    <label 
                      htmlFor="name" 
                      className="block mb-2 text-white"
                      style={{ fontFamily: 'var(--font-mono)' }}
                    >
                      Nom complet *
                    </label>
                    <input
                      type="text"
                      id="name"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({...formData, name: e.target.value})}
                      className="w-full px-4 py-3 bg-onyx border border-gray-medium text-white focus:border-red-accent focus:outline-none transition-colors"
                      style={{ borderRadius: '4px' }}
                      placeholder="Jean Dupont"
                    />
                  </div>

                  <div>
                    <label 
                      htmlFor="email" 
                      className="block mb-2 text-white"
                      style={{ fontFamily: 'var(--font-mono)' }}
                    >
                      Email *
                    </label>
                    <input
                      type="email"
                      id="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      className="w-full px-4 py-3 bg-onyx border border-gray-medium text-white focus:border-red-accent focus:outline-none transition-colors"
                      style={{ borderRadius: '4px' }}
                      placeholder="jean@exemple.com"
                    />
                  </div>

                  <div>
                    <label 
                      htmlFor="company" 
                      className="block mb-2 text-white"
                      style={{ fontFamily: 'var(--font-mono)' }}
                    >
                      Entreprise
                    </label>
                    <input
                      type="text"
                      id="company"
                      value={formData.company}
                      onChange={(e) => setFormData({...formData, company: e.target.value})}
                      className="w-full px-4 py-3 bg-onyx border border-gray-medium text-white focus:border-red-accent focus:outline-none transition-colors"
                      style={{ borderRadius: '4px' }}
                      placeholder="Votre entreprise"
                    />
                  </div>
                </div>
              </div>

              {/* Step 2: Project Details */}
              <div className="p-8 border border-gray-medium bg-gray-dark"
                   style={{ borderRadius: '8px' }}>
                <div className="flex items-center justify-between mb-6">
                  <h3 
                    className="text-2xl text-white"
                    style={{ fontFamily: 'var(--font-heading)' }}
                  >
                    Détails du projet
                  </h3>
                  <Tag variant="accent">Étape 2/3</Tag>
                </div>

                <div className="space-y-6">
                  <div>
                    <label 
                      className="block mb-3 text-white"
                      style={{ fontFamily: 'var(--font-mono)' }}
                    >
                      Type de projet *
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {projectTypes.map((type) => (
                        <button
                          key={type}
                          type="button"
                          onClick={() => setFormData({...formData, projectType: type})}
                          className={`px-4 py-3 border text-left transition-all ${formData.projectType === type ? 'border-red-accent bg-red-accent text-white' : 'border-gray-medium text-muted-foreground hover:border-white hover:text-white'}`}
                          style={{ borderRadius: '4px' }}
                        >
                          {type}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label 
                      className="block mb-3 text-white"
                      style={{ fontFamily: 'var(--font-mono)' }}
                    >
                      Budget estimé *
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {budgetRanges.map((budget) => (
                        <button
                          key={budget}
                          type="button"
                          onClick={() => setFormData({...formData, budget})}
                          className={`px-4 py-3 border text-left transition-all ${formData.budget === budget ? 'border-red-accent bg-red-accent text-white' : 'border-gray-medium text-muted-foreground hover:border-white hover:text-white'}`}
                          style={{ borderRadius: '4px' }}
                        >
                          {budget}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label 
                      className="block mb-3 text-white"
                      style={{ fontFamily: 'var(--font-mono)' }}
                    >
                      Délai souhaité *
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {timelines.map((timeline) => (
                        <button
                          key={timeline}
                          type="button"
                          onClick={() => setFormData({...formData, timeline})}
                          className={`px-4 py-3 border text-left transition-all ${formData.timeline === timeline ? 'border-red-accent bg-red-accent text-white' : 'border-gray-medium text-muted-foreground hover:border-white hover:text-white'}`}
                          style={{ borderRadius: '4px' }}
                        >
                          {timeline}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Step 3: Message */}
              <div className="p-8 border border-gray-medium bg-gray-dark"
                   style={{ borderRadius: '8px' }}>
                <div className="flex items-center justify-between mb-6">
                  <h3 
                    className="text-2xl text-white"
                    style={{ fontFamily: 'var(--font-heading)' }}
                  >
                    Votre message
                  </h3>
                  <Tag variant="accent">Étape 3/3</Tag>
                </div>

                <div>
                  <label 
                    htmlFor="message" 
                    className="block mb-2 text-white"
                    style={{ fontFamily: 'var(--font-mono)' }}
                  >
                    Décrivez votre projet *
                  </label>
                  <textarea
                    id="message"
                    required
                    rows={8}
                    value={formData.message}
                    onChange={(e) => setFormData({...formData, message: e.target.value})}
                    className="w-full px-4 py-3 bg-onyx border border-gray-medium text-white focus:border-red-accent focus:outline-none transition-colors resize-none"
                    style={{ borderRadius: '4px' }}
                    placeholder="Parlez-nous de votre projet, vos objectifs, vos contraintes..."
                  />
                  <p className="mt-2 text-sm text-muted-foreground">
                    Plus vous serez précis, mieux nous pourrons vous répondre.
                  </p>
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                className="w-full py-4 bg-red-accent text-white transition-all duration-300 hover:bg-white hover:text-onyx flex items-center justify-center gap-2 group"
                style={{ borderRadius: '4px', fontFamily: 'var(--font-body)' }}
              >
                <Send className="w-5 h-5" />
                Envoyer le message
              </button>

              <p className="text-center text-sm text-muted-foreground">
                En soumettant ce formulaire, vous acceptez que nous utilisions vos données pour vous recontacter au sujet de votre projet.
              </p>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
