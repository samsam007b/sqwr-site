export interface Project {
  id: string;
  title: string;
  client: string;
  industry: string;
  poles: ('Graphisme' | 'Code' | 'Communication')[];
  deliverables: string[];
  kpis: {
    label: string;
    value: string;
  }[];
  coverStyle: 'Code' | 'Graphisme' | 'Communication';
  description: string;
  context?: string;
  challenge?: string;
  approach?: string[];
  results?: string;
  stack?: string[];
  credits?: string[];
  featured?: boolean;
}

export const projects: Project[] = [
  {
    id: 'squarebrew',
    title: 'SquareBrew',
    client: 'SquareBrew Coffee',
    industry: 'Food & Beverage',
    poles: ['Graphisme', 'Code', 'Communication'],
    deliverables: ['Identité', 'Packaging', 'Design système web', 'Shopify', 'Campagne lancement'],
    kpis: [
      { label: 'Conversion', value: '+42%' },
      { label: 'Trafic organique', value: '+3.1×' }
    ],
    coverStyle: 'Code',
    description: 'Rebranding & site e-commerce',
    context: 'SquareBrew Coffee souhaitait moderniser son identité et lancer sa boutique en ligne pour atteindre une clientèle urbaine et exigeante.',
    challenge: 'Créer une identité forte qui se démarque dans un marché saturé tout en assurant une expérience e-commerce fluide et performante.',
    approach: [
      'Refonte complète de l\'identité avec un système modulaire basé sur la forme carrée',
      'Développement d\'un site Shopify optimisé avec animations subtiles',
      'Campagne de lancement cross-canal avec contenus sociaux et emailings'
    ],
    results: 'Le site a généré +42% de conversion dès les 3 premiers mois et le trafic organique a triplé grâce au SEO et à la campagne.',
    stack: ['Shopify', 'Liquid', 'JavaScript', 'GSAP'],
    featured: true
  },
  {
    id: 'monolithe',
    title: 'Monolithe',
    client: 'Monolithe Architecture',
    industry: 'Architecture',
    poles: ['Graphisme'],
    deliverables: ['Logo modulaire', 'Charte 64p', 'Papeterie', 'Signalétique'],
    kpis: [
      { label: 'Nouveaux appels d\'offres', value: '+5/mois' }
    ],
    coverStyle: 'Graphisme',
    description: 'Identité & guidelines',
    context: 'Cabinet d\'architecture cherchant à affirmer son positionnement premium et structuré.',
    challenge: 'Traduire la rigueur architecturale en une identité visuelle évolutive et mémorable.',
    approach: [
      'Conception d\'un logo modulaire s\'adaptant aux formats',
      'Élaboration d\'une charte graphique de 64 pages détaillée',
      'Déploiement sur tous les supports print et signalétique'
    ],
    results: 'L\'identité a renforcé la crédibilité du cabinet, générant 5 nouveaux appels d\'offres par mois.',
    featured: true
  },
  {
    id: 'flare',
    title: 'Flare',
    client: 'Flare.io',
    industry: 'Logiciel B2B',
    poles: ['Code', 'Graphisme'],
    deliverables: ['Site Next.js', 'DS Figma', 'Illustrations', 'Blog', 'Analytics'],
    kpis: [
      { label: 'Bounce rate', value: '-38%' },
      { label: 'MQL trimestriels', value: '+120' }
    ],
    coverStyle: 'Code',
    description: 'SaaS website + design système',
    context: 'Startup SaaS B2B nécessitant un site vitrine performant et un design système cohérent.',
    challenge: 'Créer une expérience web moderne qui convertit tout en établissant les bases d\'un design système scalable.',
    approach: [
      'Développement Next.js avec SSG pour la performance',
      'Création d\'un design système complet dans Figma',
      'Intégration de micro-interactions et analytics avancées'
    ],
    results: 'Le bounce rate a chuté de 38% et les MQL ont augmenté de 120 par trimestre.',
    stack: ['Next.js', 'TypeScript', 'Tailwind CSS', 'Framer Motion', 'Vercel'],
    featured: true
  },
  {
    id: 'novarun',
    title: 'NovaRun',
    client: 'NovaRun',
    industry: 'Sport/Health',
    poles: ['Code'],
    deliverables: ['UX flows', 'UI kit', 'React Native', 'Onboarding', 'Empty states'],
    kpis: [
      { label: 'Retention J7', value: '34%' }
    ],
    coverStyle: 'Code',
    description: 'App mobile (MVP)',
    context: 'Application mobile de tracking sportif pour runners débutants et intermédiaires.',
    challenge: 'Concevoir une expérience mobile intuitive avec un onboarding efficace pour maximiser la rétention.',
    approach: [
      'Recherche utilisateur et flows UX optimisés',
      'Développement React Native avec animations fluides',
      'Tests utilisateurs itératifs pour affiner l\'onboarding'
    ],
    results: 'Taux de rétention de 34% à J7, au-dessus de la moyenne du secteur.',
    stack: ['React Native', 'Expo', 'TypeScript', 'Firebase']
  },
  {
    id: 'musea',
    title: 'Musea',
    client: 'Musée des Passages',
    industry: 'Culture',
    poles: ['Graphisme', 'Communication'],
    deliverables: ['Affiche', 'Catalogue', 'Signalétique', 'Microsite événement'],
    kpis: [
      { label: 'Visiteurs en 6 semaines', value: '18k' }
    ],
    coverStyle: 'Graphisme',
    description: 'Scénographie & identité d\'exposition',
    context: 'Exposition temporaire nécessitant une identité forte et une communication multi-supports.',
    challenge: 'Créer une identité visuelle qui fonctionne du print au digital tout en respectant l\'univers du musée.',
    approach: [
      'Conception d\'une identité modulaire pour l\'exposition',
      'Production du catalogue et signalétique in situ',
      'Microsite événement avec billetterie intégrée'
    ],
    results: '18 000 visiteurs sur 6 semaines, dépassant les objectifs de 40%.',
    featured: true
  },
  {
    id: 'parallele',
    title: 'Parallèle',
    client: 'Parallèle Magazine',
    industry: 'Média',
    poles: ['Graphisme'],
    deliverables: ['Direction artistique', 'Shooting 2 jours', 'Retouches', 'Maquette éditoriale'],
    kpis: [
      { label: 'Abonnements numériques', value: '+30%' }
    ],
    coverStyle: 'Graphisme',
    description: 'Direction photo & édition',
    context: 'Magazine lifestyle cherchant à renouveler son approche éditoriale et photographique.',
    challenge: 'Créer une direction artistique distinctive qui modernise le magazine sans perdre son ADN.',
    approach: [
      'Direction artistique pour un shooting de 2 jours',
      'Retouches photo haute qualité',
      'Maquette éditoriale moderne et aérée'
    ],
    results: 'Augmentation de 30% des abonnements numériques suite au numéro.',
    featured: true
  },
  {
    id: 'loop-market',
    title: 'Loop Market',
    client: 'Loop',
    industry: 'Circular Retail',
    poles: ['Graphisme', 'Communication'],
    deliverables: ['Logo', 'Pack social', 'Motion 6s', 'Toolkit UGC'],
    kpis: [
      { label: 'Reach', value: '+280%' },
      { label: 'CPC', value: '-22%' }
    ],
    coverStyle: 'Communication',
    description: 'Identité & campagne social',
    context: 'Plateforme de seconde main cherchant à se positionner sur le marché de la mode circulaire.',
    challenge: 'Créer une identité et une stratégie social media qui résonne avec la Gen Z.',
    approach: [
      'Identité dynamique et engagée',
      'Pack social avec templates animés',
      'Toolkit UGC pour maximiser l\'engagement communautaire'
    ],
    results: 'Reach multiplié par 2.8 et coût par clic réduit de 22%.'
  },
  {
    id: 'cobalt',
    title: 'Cobalt',
    client: 'Cobalt Energy',
    industry: 'Energie',
    poles: ['Code'],
    deliverables: ['Webapp Next.js', 'Charts Recharts', 'Auth', 'Gestion rôles'],
    kpis: [
      { label: 'Temps de reporting', value: '-40%' }
    ],
    coverStyle: 'Code',
    description: 'Webapp tableau de bord',
    context: 'Entreprise d\'énergie nécessitant un outil interne de reporting et visualisation de données.',
    challenge: 'Développer une webapp performante avec des visualisations de données complexes et un système d\'authentification robuste.',
    approach: [
      'Architecture Next.js avec API routes sécurisées',
      'Visualisations de données avec Recharts',
      'Système d\'authentification et gestion des rôles'
    ],
    results: 'Réduction de 40% du temps de reporting pour les équipes opérationnelles.',
    stack: ['Next.js', 'TypeScript', 'Recharts', 'NextAuth', 'PostgreSQL']
  },
  {
    id: 'radian',
    title: 'Radian',
    client: 'Radian Studio',
    industry: 'Design',
    poles: ['Graphisme', 'Code'],
    deliverables: ['Identité', 'Site headless (Sanity)', 'Cases animés'],
    kpis: [
      { label: 'Contrats >50k€', value: '+3/an' }
    ],
    coverStyle: 'Code',
    description: 'Refonte marque & site vitrine',
    context: 'Studio de design souhaitant moderniser son image et son portfolio en ligne.',
    challenge: 'Créer une identité et un site qui reflètent l\'expertise du studio tout en facilitant la mise à jour des projets.',
    approach: [
      'Nouvelle identité avec système modulaire',
      'Site headless avec Sanity CMS pour flexibilité',
      'Animations sur-mesure pour les cases'
    ],
    results: '3 nouveaux contrats premium (>50k€) par an grâce à la crédibilité renforcée.',
    stack: ['Next.js', 'Sanity', 'GSAP', 'TypeScript'],
    featured: true
  },
  {
    id: 'klin',
    title: 'Klin',
    client: 'Klin',
    industry: 'Hygiène',
    poles: ['Graphisme'],
    deliverables: ['Architecture de gamme', 'Pictos 24px', 'Fiches PLV'],
    kpis: [],
    coverStyle: 'Graphisme',
    description: 'Système de packaging & icônes',
    context: 'Marque d\'hygiène nécessitant une refonte complète de son architecture de gamme.',
    challenge: 'Créer un système cohérent et scalable pour une gamme de 20+ produits.',
    approach: [
      'Audit de la gamme existante et recommandations',
      'Système d\'icônes 24px modulaire',
      'Templates PLV et guidelines packaging'
    ],
    results: 'Système de packaging déployé sur toute la gamme avec succès.'
  },
  {
    id: 'arpege',
    title: 'Arpège',
    client: 'Festival Arpège',
    industry: 'Event',
    poles: ['Graphisme', 'Communication'],
    deliverables: ['Affiche', 'Plan de scène', 'Écrans LED', 'Stories', 'Pass'],
    kpis: [
      { label: 'Taux de remplissage', value: '97%' }
    ],
    coverStyle: 'Communication',
    description: 'Identité d\'événement & habillages',
    context: 'Festival de musique électronique cherchant une identité visuelle impactante.',
    challenge: 'Créer une identité qui fonctionne à toutes les échelles, des stories aux écrans LED géants.',
    approach: [
      'Identité graphique modulaire et dynamique',
      'Déclinaisons pour tous les supports physiques et digitaux',
      'Animations pour écrans LED et réseaux sociaux'
    ],
    results: 'Taux de remplissage de 97%, avec une forte visibilité sur les réseaux.'
  },
  {
    id: 'easyco',
    title: 'EasyCo',
    client: 'EasyCo',
    industry: 'Immobilier/Coliving',
    poles: ['Code', 'Graphisme'],
    deliverables: ['Prototype Figma', 'Landing conversion', 'Illustrations 3D légères'],
    kpis: [
      { label: 'Conversion lead', value: '6.8%' }
    ],
    coverStyle: 'Code',
    description: 'UI prototype & landing',
    context: 'Startup de coliving nécessitant une landing page optimisée pour la conversion.',
    challenge: 'Créer une expérience utilisateur qui génère des leads qualifiés tout en présentant le concept innovant.',
    approach: [
      'Prototype Figma haute fidélité testé avec utilisateurs',
      'Landing page optimisée conversion avec A/B testing',
      'Illustrations 3D légères pour performance'
    ],
    results: 'Taux de conversion de 6.8%, nettement au-dessus de la moyenne du secteur.',
    stack: ['Next.js', 'TypeScript', 'Framer Motion', 'Spline']
  },
  {
    id: 'atelier-nord',
    title: 'Atelier Nord',
    client: 'Atelier Nord',
    industry: 'Art & Craft',
    poles: ['Graphisme'],
    deliverables: ['Monogramme pixel', 'Catalogue', 'Portfolio statique'],
    kpis: [],
    coverStyle: 'Graphisme',
    description: 'Identité artistique',
    context: 'Atelier d\'artiste cherchant une identité visuelle distinctive et intemporelle.',
    challenge: 'Créer une identité qui respecte l\'esthétique artisanale tout en étant moderne.',
    approach: [
      'Monogramme pixel inspiré de la grille de travail de l\'atelier',
      'Catalogue présentant les œuvres de manière épurée',
      'Portfolio web minimaliste'
    ],
    results: 'Identité déployée avec succès sur tous les supports.'
  },
  {
    id: 'flux',
    title: 'Flux',
    client: 'Flux Mobility',
    industry: 'Mobilité',
    poles: ['Communication'],
    deliverables: ['Calendrier 3 mois', 'Templates Figma', 'Motion 9:16', 'Guidelines tonales'],
    kpis: [
      { label: 'Nouveaux abonnés', value: '+12k en 90j' }
    ],
    coverStyle: 'Communication',
    description: 'Kit social & lignes éditoriales',
    context: 'Startup de mobilité urbaine cherchant à construire une présence sociale forte.',
    challenge: 'Créer une stratégie de contenu cohérente et des templates facilement utilisables en interne.',
    approach: [
      'Audit et stratégie de contenu sur 3 mois',
      'Templates Figma pour stories et posts',
      'Guidelines tonales et visuelles complètes'
    ],
    results: '+12 000 abonnés en 90 jours avec un engagement soutenu.'
  }
];

export const featuredProjects = projects.filter(p => p.featured);
